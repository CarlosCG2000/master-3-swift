//
//  Pokemon+CoreDataClass.swift
//  CoreDataStakck
//
//  Created by Rodrigo Extremo Tabarés on 24/2/24.
//
//

import Foundation
import CoreData

@objc(Pokemon)
public class Pokemon: NSManagedObject {

}
