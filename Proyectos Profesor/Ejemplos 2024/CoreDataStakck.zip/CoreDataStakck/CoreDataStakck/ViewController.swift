//
//  ViewController.swift
//  CoreDataStakck
//
//  Created by Rodrigo Extremo Tabarés on 24/2/24.
//

import UIKit

class ViewController: UIViewController {
    let manager = CoreDataManager()
    override func viewDidLoad() {
        super.viewDidLoad()
        
        manager.savePokemon(name: "yo")
        manager.fetch2()
        
    }


}

