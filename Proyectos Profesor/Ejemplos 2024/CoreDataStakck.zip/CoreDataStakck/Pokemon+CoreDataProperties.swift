//
//  Pokemon+CoreDataProperties.swift
//  CoreDataStakck
//
//  Created by Rodrigo Extremo Tabarés on 24/2/24.
//
//

import Foundation
import CoreData


extension Pokemon {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Pokemon> {
        return NSFetchRequest<Pokemon>(entityName: "Pokemon")
    }

    @NSManaged public var name: String?

}

extension Pokemon : Identifiable {

}
