//
//  AprendiendoCoreDataApp.swift
//  AprendiendoCoreData
//
//  Created by Rodrigo Extremo Tabarés on 28/2/24.
//

import SwiftUI

@main
struct AprendiendoCoreDataApp: App {
    let persistenceController = PersistenceController.shared

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, persistenceController.container.viewContext)
        }
    }
}
