//
//  HeaderView.swift
//  EjemploListas
//
//  Created by Rodrigo Extremo Tabarés on 21/2/24.
//

import SwiftUI

struct HeaderView: View {
    
    @Binding var loginState: LoginState
    
    var body: some View {
        VStack {
            HStack {
                if self.loginState == .connected {
                    Image("user")
                        .resizable()
                        .scaledToFit()
                        .clipShape(Circle())
                        .frame(height: 40)
                        .padding()
                } else {
                    Image(systemName: "person.crop.circle.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 40)
                        .foregroundColor(.blue)
                        .padding()
                }
                VStack(alignment: .leading) {
                    Button {
                        if loginState == .disconected {
                            self.loginState = .connected
                        } else {
                            self.loginState = .disconected
                        }
                    } label: {
                        Text(self.loginState == .disconected ? "Iniciar sesión en el iPhone" : "Steve Jobs")
                    }
                    Text("Configura iCloud, App Store y más ")
                }
                .font(.footnote)
                .padding(.leading, 10)
            }
        }
    }
}

#Preview {
    HeaderView(loginState: .constant(.disconected))
}
