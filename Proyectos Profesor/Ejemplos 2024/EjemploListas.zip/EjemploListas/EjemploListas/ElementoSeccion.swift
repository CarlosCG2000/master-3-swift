//
//  ElementoSeccion.swift
//  EjemploListas
//
//  Created by Rodrigo Extremo Tabarés on 21/2/24.
//

import Foundation

struct ElementoSeccion: Identifiable {
    var id = UUID()
    
    let titulo: String
}
