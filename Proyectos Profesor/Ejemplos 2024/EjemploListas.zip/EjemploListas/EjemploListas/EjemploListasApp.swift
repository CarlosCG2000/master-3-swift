//
//  EjemploListasApp.swift
//  EjemploListas
//
//  Created by Rodrigo Extremo Tabarés on 21/2/24.
//

import SwiftUI

@main
struct EjemploListasApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
