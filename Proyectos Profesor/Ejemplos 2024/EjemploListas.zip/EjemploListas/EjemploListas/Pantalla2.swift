//
//  Pantalla2.swift
//  EjemploListas
//
//  Created by Rodrigo Extremo Tabarés on 21/2/24.
//

import SwiftUI

struct Pantalla2: View {
    
    let data: String
    
    var body: some View {
        Text("\(data)")
    }
}

#Preview {
    Pantalla2(data: "")
}
