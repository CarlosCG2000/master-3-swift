//
//  ContentView.swift
//  EjemploListas
//
//  Created by Rodrigo Extremo Tabarés on 21/2/24.
//

import SwiftUI

enum LoginState {
    case disconected
    case connected
}

struct ContentView: View {
    @State var dataSource: [ElementoSeccion] = [
        .init(titulo: "Tiempo de uso"),
        .init(titulo: "General"),
        .init(titulo: "Accesibilidad"),
        .init(titulo: "Privacidad y seguridad"),
        .init(titulo: "Accesibilidad")
    ]
    @State var loginState: LoginState = .disconected
    
    var body: some View {
        NavigationView {
            VStack {
                List {
                    Section("Usuario") {
                        HeaderView(loginState: $loginState)
                    }
                    Section("Pantallas adicionales") {
                        ForEach(dataSource, id: \.id) { item in
                            NavigationLink {
                                Pantalla2(data: item.titulo)
                            } label: {
                                Text("\(item.titulo)")
                            }
                        }
                    }
                }
            }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
