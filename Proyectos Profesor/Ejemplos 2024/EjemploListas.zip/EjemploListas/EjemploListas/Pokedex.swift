//
//  Pokedex.swift
//  EjemploListas
//
//  Created by Rodrigo Extremo Tabarés on 21/2/24.
//

import SwiftUI
import Kingfisher

struct Pokedex: View {
    
    @State var zoom: CGFloat
    
    var body: some View {
        VStack {
            LazyVGrid(columns: [GridItem(.fixed(40)), GridItem(.fixed(40)), GridItem(.fixed(40)),GridItem(.fixed(40))], content: {
                ForEach(1..<150, id: \.self) { item in
                    KFImage(URL(string: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/\(item).png"))
                        .resizable()
                        .scaledToFit()
                }
                
            })
            Spacer()
            Slider(value: $zoom, in: 20...30)
        }
        
    }
}

#Preview {
    Pokedex(zoom: 20)
}
