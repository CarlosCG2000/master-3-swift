//
//  ImagenCollectionViewCell.swift
//  EjemploTablas
//
//  Created by Rodrigo Extremo Tabarés on 21/2/24.
//

import UIKit

class ImagenCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var ivImagen: UIImageView!
    
}
