//
//  ProfileTableViewCell.swift
//  EjemploTablas
//
//  Created by Rodrigo Extremo Tabarés on 21/2/24.
//

import UIKit

protocol ProfileTableViewCellDelegate: AnyObject {
    func userWantsToAuthenticate()
}

class ProfileTableViewCell: UITableViewCell {
    
    
    @IBOutlet weak var ivProfile: UIImageView!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var lblSubtitle: UILabel!
    weak var delegate: ProfileTableViewCellDelegate?

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    @IBAction func btnLoginPressed(_ sender: Any) {
        print("Entro en el botón")
        delegate?.userWantsToAuthenticate()
    }

}
