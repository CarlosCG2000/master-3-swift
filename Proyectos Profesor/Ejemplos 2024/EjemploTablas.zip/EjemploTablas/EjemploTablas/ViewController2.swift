//
//  ViewController2.swift
//  EjemploTablas
//
//  Created by Rodrigo Extremo Tabarés on 21/2/24.
//

import UIKit
import Kingfisher

class ViewController2: UIViewController {


    @IBOutlet weak var collectionView: UICollectionView!
    
    var data: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = data
        // Do any additional setup after loading the view.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


extension ViewController2: UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 1250
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "imagenCell", for: indexPath) as! ImagenCollectionViewCell
        if let url = URL(string: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/\(indexPath.row + 1).png") {
            cell.ivImagen.kf.setImage(with: url)
        }
        // Poner imagen
        return cell
    }
    
    
}

extension ViewController2: UICollectionViewDelegate {
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        let item = URL(string: "https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/other/official-artwork/\(indexPath.row + 1).png")
        self.performSegue(withIdentifier: "", sender: item)
    }
    
}
