//
//  UIImage+Orientation.swift
//  EjemploTablas
//
//  Created by Rodrigo Extremo Tabarés on 21/2/24.
//

import UIKit

extension UIImage {
    func fixRotation() -> UIImage {
        return UIImage()
    }
}
