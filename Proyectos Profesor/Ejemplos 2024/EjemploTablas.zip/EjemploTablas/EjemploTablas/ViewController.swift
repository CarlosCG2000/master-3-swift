//
//  ViewController.swift
//  EjemploTablas
//
//  Created by Rodrigo Extremo Tabarés on 21/2/24.
//

import UIKit

enum LoginState {
    case disconected
    case connected
}

class ViewController: UIViewController {
    
    var dataSource = ["Tiempo de uso", "General", "Accesibilidad", "Privacidad y seguridad"]
    var loginState: LoginState = .disconected
    
    @IBOutlet weak var tableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
//        let uiImage = UIImage(named: "house")
//        uiImage?.fixRotation()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetailScreen" {
            if let destination = segue.destination as? ViewController2 {
                destination.data = sender as? String ?? ""
            }
        }
    }
}


extension ViewController: UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0 {
            return 1
        }
        else {
            return dataSource.count
        }
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0 {
            return "Usuario"
        } else {
            return "Pantallas adicionales"
        }
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 2
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        if indexPath.section == 0 {
            // Retornamos un tipo de celda
            let cell = tableView.dequeueReusableCell(withIdentifier: "celdaiCloud", for: indexPath) as! ProfileTableViewCell
            cell.delegate = self
            if self.loginState == .connected {
                cell.lblSubtitle.isHidden = true
                cell.btnLogin.setTitle("Steve Jobs", for: .normal)
                cell.ivProfile.image = UIImage(named: "user")
            } else {
                cell.lblSubtitle.isHidden = false
                cell.btnLogin.setTitle("Iniciar sesión en el iPhone", for: .normal)
                cell.ivProfile.image = UIImage(systemName: "person.crop.circle.fill")
            }
            return cell
        } else {
            let cell = tableView.dequeueReusableCell(withIdentifier: "celdaDisclosure", for: indexPath)
            cell.textLabel?.text = dataSource[indexPath.row]
            if indexPath.row % 2 == 0 {
                cell.imageView?.image = UIImage(systemName: "house")
            } else {
                cell.imageView?.image = UIImage(systemName: "network")
            }
            return cell
        }
    }
}

extension ViewController:  UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let element = dataSource[indexPath.row]
        self.performSegue(withIdentifier: "showDetailScreen", sender: element)
    }
}

extension ViewController: ProfileTableViewCellDelegate {
    func userWantsToAuthenticate() {
        print("entro en el delegado de celda profile")
        // TODO: Lógica de login
        if self.loginState == .disconected {
            self.loginState = .connected
        } else {
            self.loginState = .disconected
        }
        self.tableView.reloadData()
    }
}
