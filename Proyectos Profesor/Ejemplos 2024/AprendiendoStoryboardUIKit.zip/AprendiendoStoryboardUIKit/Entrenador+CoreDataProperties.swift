//
//  Entrenador+CoreDataProperties.swift
//  AprendiendoStoryboardUIKit
//
//  Created by Rodrigo Extremo Tabarés on 28/2/24.
//
//

import Foundation
import CoreData


extension Entrenador {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Entrenador> {
        return NSFetchRequest<Entrenador>(entityName: "Entrenador")
    }

    @NSManaged public var nombre: String?
    @NSManaged public var id: Int16
    @NSManaged public var tienePokemon: NSSet?

}

// MARK: Generated accessors for tienePokemon
extension Entrenador {

    @objc(addTienePokemonObject:)
    @NSManaged public func addToTienePokemon(_ value: Pokemon)

    @objc(removeTienePokemonObject:)
    @NSManaged public func removeFromTienePokemon(_ value: Pokemon)

    @objc(addTienePokemon:)
    @NSManaged public func addToTienePokemon(_ values: NSSet)

    @objc(removeTienePokemon:)
    @NSManaged public func removeFromTienePokemon(_ values: NSSet)

}

extension Entrenador : Identifiable {

}
