//
//  Entrenador+CoreDataClass.swift
//  AprendiendoStoryboardUIKit
//
//  Created by Rodrigo Extremo Tabarés on 28/2/24.
//
//

import Foundation
import CoreData

@objc(Entrenador)
public class Entrenador: NSManagedObject {

}
