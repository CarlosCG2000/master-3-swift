//
//  Pokemon+CoreDataProperties.swift
//  AprendiendoStoryboardUIKit
//
//  Created by Rodrigo Extremo Tabarés on 28/2/24.
//
//

import Foundation
import CoreData


extension Pokemon {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Pokemon> {
        return NSFetchRequest<Pokemon>(entityName: "Pokemon")
    }

    @NSManaged public var name: String?
    @NSManaged public var weight: Double
    @NSManaged public var height: Double
    @NSManaged public var id: Int16
    @NSManaged public var esEntrenadoPor: Entrenador?

}

extension Pokemon : Identifiable {

}
