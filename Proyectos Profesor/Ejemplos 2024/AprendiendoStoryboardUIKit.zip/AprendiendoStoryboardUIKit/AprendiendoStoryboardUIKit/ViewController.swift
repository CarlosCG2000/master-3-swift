//
//  ViewController.swift
//  AprendiendoStoryboardUIKit
//
//  Created by Rodrigo Extremo Tabarés on 28/2/24.
//

import UIKit

class ViewController: UIViewController {
    
    let manager = CoreDataManager.shared
    var pokemon: Pokemon?
    var entrenador: Entrenador?
    var todosPokemon: [Pokemon] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        do {
            let pokemones = try manager.recuperarPokemon()
            let pikachus = try manager.recuperarPikachus()
            print(pikachus.map(\.name))
            let pikachusPorNombre = try manager.recuperar(pokemon: "Pikachu")
            print(pikachusPorNombre.map(\.name))
            let bulbasaursPorNombre = try manager.recuperar(pokemon: "Bulbasaur")
            print(bulbasaursPorNombre.map(\.name))
        } catch {
            print(error)
        }
        
    }
    
    
    // MARK: - CRUD
    
    // CREATE
    @IBAction func crear(_ sender: Any) {
        self.pokemon = manager.crearPokemon(id: 2, name: "Bulbasaur", altura: 1, peso: 1)
        self.entrenador = manager.crearEntrenador(id: 1, name: "Rodrigo")
        print(pokemon)
    }
    
    @IBAction func entrenar(_ sender: Any) {
        if let pokemon = self.pokemon, let entrenador = self.entrenador {
            manager.asignar(pokemon: pokemon, aEntrenador: entrenador)
        }
    }
    
    // UPDATE
    @IBAction func actualizar(_ sender: Any) {
        if let pokemon {
            pokemon.name = "Pikachu"
            self.manager.actualizar(pokemon: pokemon)
            print(pokemon)
        }
    }
    
    
    /// DELETE
    @IBAction func borrar(_ sender: Any) {
        if let pokemon {
            manager.borrar(pokemon: pokemon)
            self.pokemon = nil
        }
    }
}

