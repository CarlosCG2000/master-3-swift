//
//  APIManager.swift
//  AprendiendoStoryboardUIKit
//
//  Created by Rodrigo Extremo Tabarés on 28/2/24.
//

import Foundation

final class APIManager: NSObject {
    // TODO: añadir algo
}
