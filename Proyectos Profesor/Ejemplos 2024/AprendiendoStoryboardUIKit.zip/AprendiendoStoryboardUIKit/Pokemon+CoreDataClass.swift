//
//  Pokemon+CoreDataClass.swift
//  AprendiendoStoryboardUIKit
//
//  Created by Rodrigo Extremo Tabarés on 28/2/24.
//
//

import Foundation
import CoreData

@objc(Pokemon)
public class Pokemon: NSManagedObject {

}
