//
//  Usuario+CoreDataClass.swift
//  MigrandoCoreData2
//
//  Created by Rodrigo Extremo Tabarés on 22/4/24.
//
//

import Foundation
import CoreData

@objc(Usuario)
public class Usuario: NSManagedObject {

}
