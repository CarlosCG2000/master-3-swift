//
//  ViewController.swift
//  MigrandoCoreData2
//
//  Created by Rodrigo Extremo Tabarés on 22/4/24.
//

import UIKit
import CoreData

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        CoreDataManager.default.saveUser(name: "Rodrigo")
    }


}

