//
//  CoreDataRepository.swift
//  MigrandoCoreData2
//
//  Created by Rodrigo Extremo Tabarés on 22/4/24.
//

import Foundation

class CoreDataRepository {
    let dataManager = CoreDataManager.default
    
    func saveUser(name: String) {
        let newUser = dataManager.createUser()
        newUser.nombre = name
        dataManager.saveContext()
    }
}
