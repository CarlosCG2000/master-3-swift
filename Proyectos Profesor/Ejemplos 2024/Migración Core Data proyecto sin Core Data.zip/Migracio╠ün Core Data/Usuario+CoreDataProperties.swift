//
//  Usuario+CoreDataProperties.swift
//  MigrandoCoreData2
//
//  Created by Rodrigo Extremo Tabarés on 22/4/24.
//
//

import Foundation
import CoreData


extension Usuario {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Usuario> {
        return NSFetchRequest<Usuario>(entityName: "Usuario")
    }

    @NSManaged public var nombre: String?

}

extension Usuario : Identifiable {

}
