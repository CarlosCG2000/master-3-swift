//
//  ContentView.swift
//  VistasRepresentadas
//
//  Created by Rodrigo Extremo Tabarés on 28/2/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
//            VistaWebPersonalizada()
            ListadoView()
        }
    }
}

#Preview {
    ContentView()
}
