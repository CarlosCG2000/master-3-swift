//
//  VistasRepresentadasApp.swift
//  VistasRepresentadas
//
//  Created by Rodrigo Extremo Tabarés on 28/2/24.
//

import SwiftUI

@main
struct VistasRepresentadasApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
