//
//  VistaWebPersonalizada.swift
//  CoordinandoVistas
//
//  Created by Rodrigo Extremo Tabarés on 28/2/24.
//

import Foundation
import WebKit
import SwiftUI

struct VistaWebPersonalizada: UIViewRepresentable {
    
    @State var cancel: Bool = false
    
    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        let webView = WKWebView(frame: .zero, configuration: configuration)
        let request = URLRequest(url: URL(string: "https://www.upsa.es")!)
        webView.load(request)
        return webView
    }
    
    func updateUIView(_ uiView: WKWebView, context: Context) {
        print("update")
        if cancel {
            uiView.stopLoading()
        }
    }
    
    typealias UIViewType = WKWebView
    
    
}
