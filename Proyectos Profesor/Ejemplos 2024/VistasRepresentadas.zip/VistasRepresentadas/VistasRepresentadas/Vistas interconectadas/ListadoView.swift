//
//  ListadoView.swift
//  VistasRepresentadas
//
//  Created by Rodrigo Extremo Tabarés on 28/2/24.
//

import Foundation
import SwiftUI

struct ListadoView: UIViewControllerRepresentable {
    typealias UIViewControllerType = ViewControllerColeccion
    
    func makeUIViewController(context: Context) -> ViewControllerColeccion {
        return UIStoryboard(name: "Main", bundle: Bundle.main).instantiateInitialViewController() as! ViewControllerColeccion
    }
    func updateUIViewController(_ uiViewController: ViewControllerColeccion, context: Context) {
        
    }

}
