import UIKit
import RMStore

class StoreManager {
    
    public static let DidPurchaseVirtualCoinsNotification = NSNotification.Name("DidPurchaseVirtualCoinsNotification")

    public static let shared = StoreManager()

    private let store = RMStore.default()!
    private let persistor = RMStoreKeychainPersistence()
    private let kRemoveAdsProductIdentifier = "es.upsa.mimo.IAPExample.removeads"
    private let kVirtualCoinsProductIdentifier = "es.upsa.mimo.IAPExample.buyvirtualcoins"
    private let productIdentifiers: [String]
    public var products: [SKProduct]

    init() {
        productIdentifiers = [kRemoveAdsProductIdentifier, kVirtualCoinsProductIdentifier]
        products = []
        store.transactionPersistor = persistor
    }

    public func refreshProducts(completionHandler: (() -> ())?) {
        store.requestProducts(Set(productIdentifiers),
                              success: { (validProducts, invalidProducts) in
                                  self.products = (validProducts as? [SKProduct]) ?? []
                                  completionHandler?()
                              }, failure: { (_) in
                                  self.products = []
                                  completionHandler?()
                              })
    }

    public func restorePurchases(completionHandler: ((Error?) -> ())?) {
        store.restoreTransactions(onSuccess: { (_) in
            completionHandler?(nil)
        }, failure: { (error) in
            completionHandler?(error)
        })
    }
    
    public func purchaseProduct(identifier: String, completionHandler: ((Error?) -> ())?) {
        store.addPayment(identifier,
                         success: { (_) in
                            if identifier == self.kVirtualCoinsProductIdentifier {
                                NotificationCenter.default.post(name: StoreManager.DidPurchaseVirtualCoinsNotification, object: self)
                            }
                            completionHandler?(nil)
                         }, failure: { (_, error) in
                            completionHandler?(error)
                         })
    }
    
    public func hasPurchasedRemoveAds() -> Bool {
        return persistor.isPurchasedProduct(ofIdentifier: kRemoveAdsProductIdentifier)
    }
}
