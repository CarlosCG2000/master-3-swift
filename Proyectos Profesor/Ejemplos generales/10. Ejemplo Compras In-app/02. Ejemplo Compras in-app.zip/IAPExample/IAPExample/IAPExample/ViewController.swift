import UIKit

class ViewController: UIViewController {

    @IBOutlet private var bannerView: UIView!
    @IBOutlet private var virtualCoinsLabel: UILabel!
    @IBOutlet private var lifesLabel: UILabel!
    
    private let storeManager = StoreManager.shared
    private let userDefaults = UserDefaults.standard
    
    private let kVirtualCoinsKey = "VirtualCoins"
    private let kLifesKey = "Lifes"
    
    private var virtualCoins: Int {
        get {
            return userDefaults.integer(forKey: kVirtualCoinsKey)
        }
        
        set {
            userDefaults.set(newValue, forKey: kVirtualCoinsKey)
            updateVirtualCoinsLabel()
        }
    }
    
    private var lifes: Int {
        get {
            return userDefaults.integer(forKey: kLifesKey)
        }
        
        set {
            userDefaults.set(newValue, forKey: kLifesKey)
            updateLifesLabel()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(forName: StoreManager.DidPurchaseVirtualCoinsNotification, object: nil, queue: nil) { [weak self] (_) in
            self?.virtualCoins += 500
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        bannerView.isHidden = storeManager.hasPurchasedRemoveAds()
        updateVirtualCoinsLabel()
        updateLifesLabel()
    }

    private func updateVirtualCoinsLabel() {
        virtualCoinsLabel.text = "Virtual Coins: \(virtualCoins)"
    }
    
    private func updateLifesLabel() {
        lifesLabel.text = "Lifes: \(lifes)"
    }
    
    @IBAction func spendCoinsPressed(_ sender: UIButton) {
        if virtualCoins >= 200 {
            virtualCoins -= 200
            lifes += 1
        }
    }
}

