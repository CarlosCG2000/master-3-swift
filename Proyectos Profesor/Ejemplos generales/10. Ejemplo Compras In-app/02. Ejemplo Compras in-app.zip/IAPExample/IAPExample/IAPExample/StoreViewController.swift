import UIKit

class StoreViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    enum Sections: Int {
        case Products
        case RestorePurchase
        case Count
    }

    @IBOutlet private var tableView: UITableView!
    @IBOutlet private var loadingView: UIView!

    private let storeManager = StoreManager.shared

    override func viewDidLoad() {
        super.viewDidLoad()

        loadingView.layer.cornerRadius = 5

        startLoading()

        storeManager.refreshProducts { 
            self.tableView.reloadData()

            self.finishLoading()
        }
    }

    private func startLoading() {
        tableView.isHidden = true
        loadingView.isHidden = false
    }

    private func finishLoading() {
        tableView.isHidden = false
        loadingView.isHidden = true
    }

    @IBAction func handleDoneTap() {
        presentingViewController?.dismiss(animated: true, completion: nil)
    }

    // MARK: UITableViewDataSource methods

    func numberOfSections(in tableView: UITableView) -> Int {
        return Sections.Count.rawValue
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        guard let section = Sections(rawValue: section) else {
            return 0
        }

        switch section {
        case .Products:
            return storeManager.products.count
        case .RestorePurchase:
            return 1
        default:
            return 0
        }
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let section = Sections(rawValue: indexPath.section) else {
            return UITableViewCell()
        }

        switch section {
        case .Products:
            let cell = tableView.dequeueReusableCell(withIdentifier: "ProductCell")!
            let product = storeManager.products[indexPath.row]
            cell.textLabel?.text = product.localizedTitle
            cell.detailTextLabel?.text = product.price.description(withLocale: product.priceLocale)
            return cell
        case .RestorePurchase:
            return tableView.dequeueReusableCell(withIdentifier: "RestorePurchasesCell")!
        default:
            return UITableViewCell()
        }
    }

    // MARK: UITableViewDelegate methods

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let section = Sections(rawValue: indexPath.section) else {
            return
        }

        switch section {
        case .Products:
            let product = storeManager.products[indexPath.row]
            
            startLoading()
            storeManager.purchaseProduct(identifier: product.productIdentifier, completionHandler: { (_) in
                self.finishLoading()
            })
            return
        case .RestorePurchase:
            startLoading()
            storeManager.restorePurchases(completionHandler: { (_) in
                self.finishLoading()
            })
        default:
            return
        }
    }

}
