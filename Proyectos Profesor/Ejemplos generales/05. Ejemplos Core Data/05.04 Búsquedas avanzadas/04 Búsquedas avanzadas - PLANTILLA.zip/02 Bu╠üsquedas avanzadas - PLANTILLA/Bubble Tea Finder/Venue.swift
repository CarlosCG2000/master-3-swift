//
//  Venue.swift
//  Bubble Tea Finder
//
//  Created by javier.pena on 12/1/16.
//  Copyright © 2016 Medianet Software. All rights reserved.
//

import Foundation
import CoreData

@objc(Venue)
class Venue: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
