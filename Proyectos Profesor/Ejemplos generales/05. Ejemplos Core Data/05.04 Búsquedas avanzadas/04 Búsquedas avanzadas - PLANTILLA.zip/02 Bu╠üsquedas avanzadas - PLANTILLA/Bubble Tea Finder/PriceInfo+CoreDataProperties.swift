//
//  PriceInfo+CoreDataProperties.swift
//  Bubble Tea Finder
//
//  Created by javier.pena on 12/1/16.
//  Copyright © 2016 Medianet Software. All rights reserved.
//
//  Delete this file and regenerate it using "Create NSManagedObject Subclass…"
//  to keep your implementation up to date with your model.
//

import Foundation
import CoreData

extension PriceInfo {

    @NSManaged var priceCategory: String?
    @NSManaged var venue: Venue?

}
