import UIKit
import CoreData

let filterViewControllerSegueIdentifier = "toFilterViewController"
let venueCellIdentifier = "VenueCell"

class ViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    var asyncFetchRequest: NSAsynchronousFetchRequest<Venue>!
    var coreDataStack: CoreDataStack!
    var fetchRequest: NSFetchRequest<Venue>!
    var venues: [Venue]! = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // TODO: fetch all venues... ASYNCHRONOUSLY
    }
    
    override func prepare(for segue: UIStoryboardSegue,
                          sender: Any?) {
        
        if segue.identifier == filterViewControllerSegueIdentifier {
            let navController =
                segue.destination as! UINavigationController
            
            let filterVC =
                navController.topViewController as! FilterViewController
            
            filterVC.coreDataStack = coreDataStack
            filterVC.delegate = self
        }
    }
    
    @IBAction func unwindToVenuListViewController(_ segue: UIStoryboardSegue) {
        
    }
    
    //MARK: - Helper methods
    
    func fetchAndReload() {
        
        do {
            venues = try coreDataStack.context.fetch(fetchRequest)
            tableView.reloadData()
            
        } catch let error as NSError {
            print("Could not fetch \(error), \(error.userInfo)")
        }
    }
}

extension ViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        return venues.count
    }
    
    func tableView(_ tableView: UITableView,
                   cellForRowAt indexPath: IndexPath)
        -> UITableViewCell {
            
            let cell =
                tableView
                    .dequeueReusableCell(withIdentifier: venueCellIdentifier)!
            
            let venue =  venues[indexPath.row]
            cell.textLabel!.text = venue.name
            cell.detailTextLabel!.text = venue.priceInfo?.priceCategory
            
            return cell
    }
}

//MARK: FilterViewControllerDelegate methods

extension ViewController: FilterViewControllerDelegate {
    
    func filterViewController(_ filter: FilterViewController,
                              didSelectPredicate predicate:NSPredicate?,
                              sortDescriptor:NSSortDescriptor?) {
        
        fetchRequest.predicate = nil
        fetchRequest.sortDescriptors = nil
        
        // TODO: configure fetch request with predicate and sort descriptor if needed
        
        fetchAndReload()
    }
}
