import UIKit
import CoreData

protocol FilterViewControllerDelegate: class {
    func filterViewController(_ filter: FilterViewController,
                              didSelectPredicate predicate:NSPredicate?,
                              sortDescriptor:NSSortDescriptor?)
}

class FilterViewController: UITableViewController {
    
    @IBOutlet weak var firstPriceCategoryLabel: UILabel!
    @IBOutlet weak var secondPriceCategoryLabel: UILabel!
    @IBOutlet weak var thirdPriceCategoryLabel: UILabel!
    @IBOutlet weak var numDealsLabel: UILabel!
    
    //Price section
    @IBOutlet weak var cheapVenueCell: UITableViewCell!
    @IBOutlet weak var moderateVenueCell: UITableViewCell!
    @IBOutlet weak var expensiveVenueCell: UITableViewCell!
    
    //Most popular section
    @IBOutlet weak var offeringDealCell: UITableViewCell!
    @IBOutlet weak var walkingDistanceCell: UITableViewCell!
    @IBOutlet weak var userTipsCell: UITableViewCell!
    
    //Sort section
    @IBOutlet weak var nameAZSortCell: UITableViewCell!
    @IBOutlet weak var nameZASortCell: UITableViewCell!
    @IBOutlet weak var distanceSortCell: UITableViewCell!
    @IBOutlet weak var priceSortCell: UITableViewCell!
    
    var coreDataStack: CoreDataStack!
    
    weak var delegate: FilterViewControllerDelegate?
    var selectedSortDescriptor: NSSortDescriptor?
    var selectedPredicate: NSPredicate?
    
    lazy var cheapVenuePredicate: NSPredicate = {
        
        // TODO: return predicate for priceCategory $
        return NSPredicate()
    }()
    
    lazy var moderateVenuePredicate: NSPredicate = {
        
        // TODO: return predicate for priceCategory $$

    }()
    
    lazy var expensiveVenuePredicate: NSPredicate = {
        
        // TODO: return predicate for priceCategory $$$
        
    }()
    
    lazy var offeringDealPredicate: NSPredicate = {
        
        // TODO: return predicate for specialCount > 0
        
    }()
    
    lazy var walkingDistancePredicate: NSPredicate = {
        
        // TODO: return predicate for distance < 1500
        
    }()
    
    lazy var hasUserTipsPredicate: NSPredicate = {
        
        // TODO: return predicate for tipCount > 0
        
    }()
    
    lazy var nameSortDescriptor: NSSortDescriptor = {
        
        // TODO: return sort descriptor by name ascending (HINT: use localized standard comparation selector)
        
    }()
    
    lazy var distanceSortDescriptor: NSSortDescriptor = {
        
        // TODO: return sort descriptor by distance ascending
        
    }()
    
    lazy var priceSortDescriptor: NSSortDescriptor = {
        
        // TODO: return sort descriptor by price category ascending
        
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        populateCheapVenueCountLabel()
        populateModerateVenueCountLabel()
        populateExpensiveVenueCountLabel()
        populateDealsCountLabel()
    }
    
    //MARK - UITableViewDelegate methods
    
    override func tableView(_ tableView: UITableView,
                            didSelectRowAt indexPath: IndexPath) {
        
        let cell = tableView.cellForRow(at: indexPath)!
        
        switch cell {
        // Price section
        case cheapVenueCell:
            selectedPredicate = cheapVenuePredicate
        case moderateVenueCell:
            selectedPredicate = moderateVenuePredicate
        case expensiveVenueCell:
            selectedPredicate = expensiveVenuePredicate
        //Most Popular section
        case offeringDealCell:
            selectedPredicate = offeringDealPredicate
        case walkingDistanceCell:
            selectedPredicate = walkingDistancePredicate
        case userTipsCell:
            selectedPredicate = hasUserTipsPredicate
        //Sort By section
        case nameAZSortCell:
            selectedSortDescriptor = nameSortDescriptor
        case nameZASortCell:
            selectedSortDescriptor =
                nameSortDescriptor.reversedSortDescriptor
                as? NSSortDescriptor
        case distanceSortCell:
            selectedSortDescriptor = distanceSortDescriptor
        case priceSortCell:
            selectedSortDescriptor = priceSortDescriptor
        default:
            print("default case")
        }
        
        cell.accessoryType = .checkmark
    }
    
    // MARK - UIButton target action
    
    @IBAction func saveButtonTapped(_ sender: UIBarButtonItem) {
        
        delegate!.filterViewController(self,
                                       didSelectPredicate: selectedPredicate,
                                       sortDescriptor: selectedSortDescriptor)
        
        dismiss(animated: true, completion:nil)
    }
    
    func populateCheapVenueCountLabel() {
        
        // TODO: show the count of CHEAP venues in the firstPriceCategoryLabel

    }
    
    func populateModerateVenueCountLabel() {
        
        // TODO: show the count of MODERATE venues in the secondPriceCategoryLabel
        
    }
    
    func populateExpensiveVenueCountLabel() {
        
        // TODO: show the count of EXPENSIVE venues in the thirdPriceCategoryLabel
        
    }
    
    func populateDealsCountLabel() {
        
        // TODO: (ADVANCED) show the sum of specialCount of all venues in the numDealsLabel

    }
    
}
