import UIKit
import CoreData

let filterViewControllerSegueIdentifier = "toFilterViewController"
let venueCellIdentifier = "VenueCell"

class ViewController: UIViewController
{
    @IBOutlet weak var tableView: UITableView!
    var asyncFetchRequest: NSAsynchronousFetchRequest<Venue>!
    var coreDataStack: CoreDataStack!
    var fetchRequest: NSFetchRequest<Venue>!
    var venues: [Venue]! = []
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let batchUpdate = NSBatchUpdateRequest(entityName: "Venue")
        
        batchUpdate.propertiesToUpdate = ["favorite" : NSNumber(value:true)]
        
        batchUpdate.affectedStores = coreDataStack.context.persistentStoreCoordinator!.persistentStores
        
        batchUpdate.resultType = .updatedObjectsCountResultType
        
        do
        {
            let batchResult = try coreDataStack.context.execute(batchUpdate) as! NSBatchUpdateResult
            
            print("Records updated \(batchResult.result!)")
        }
        catch let error as NSError
        {
            print("Could not update \(error), \(error.userInfo)")
        }
        
        //1
        fetchRequest = NSFetchRequest(entityName: "Venue")
        
        //2
        asyncFetchRequest = NSAsynchronousFetchRequest(fetchRequest: fetchRequest)
            { [unowned self] (result: NSAsynchronousFetchResult! )
                -> Void in
                self.venues = result.finalResult
                self.tableView.reloadData()
        }
        
        //3
        do
        {
            try coreDataStack.context.execute(asyncFetchRequest)
        }
        catch let error as NSError
        {
            print("Could not fetch \(error), \(error.userInfo)")
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue,
                          sender: Any?)
    {
        if segue.identifier == filterViewControllerSegueIdentifier
        {
            let navController = segue.destination as! UINavigationController
            
            let filterVC = navController.topViewController as! FilterViewController
            
            filterVC.coreDataStack = coreDataStack
            filterVC.delegate = self
        }
    }
    
    @IBAction func unwindToVenuListViewController(_ segue: UIStoryboardSegue)
    {
        
    }
    
    //MARK: - Helper methods
    
    func fetchAndReload()
    {
        do
        {
            venues = try coreDataStack.context.fetch(fetchRequest)
            tableView.reloadData()
            
        }
        catch let error as NSError
        {
            print("Could not fetch \(error), \(error.userInfo)")
        }
    }
}

extension ViewController: UITableViewDataSource
{
    func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int
    {
        return venues.count
    }
    
    func tableView(_ tableView: UITableView,
                   cellForRowAt indexPath: IndexPath)
        -> UITableViewCell
    {
            let cell = tableView.dequeueReusableCell(withIdentifier: venueCellIdentifier)!
            
            let venue =  venues[indexPath.row]
            cell.textLabel!.text = venue.name
            cell.detailTextLabel!.text = venue.priceInfo?.priceCategory
            
            return cell
    }
}

//MARK: FilterViewControllerDelegate methods

extension ViewController: FilterViewControllerDelegate
{
    func filterViewController(_ filter: FilterViewController,
                              didSelectPredicate predicate:NSPredicate?,
                              sortDescriptor:NSSortDescriptor?)
    {
        fetchRequest.predicate = nil
        fetchRequest.sortDescriptors = nil
        
        if let fetchPredicate = predicate
        {
            fetchRequest.predicate = fetchPredicate
        }
        
        if let sr = sortDescriptor
        {
            fetchRequest.sortDescriptors = [sr]
        }
        
        fetchAndReload()
    }
}
