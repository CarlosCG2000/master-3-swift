import UIKit
import CoreData

protocol FilterViewControllerDelegate: class
{
    func filterViewController(_ filter: FilterViewController,
                              didSelectPredicate predicate:NSPredicate?,
                              sortDescriptor:NSSortDescriptor?)
}

class FilterViewController: UITableViewController
{
    @IBOutlet weak var firstPriceCategoryLabel: UILabel!
    @IBOutlet weak var secondPriceCategoryLabel: UILabel!
    @IBOutlet weak var thirdPriceCategoryLabel: UILabel!
    @IBOutlet weak var numDealsLabel: UILabel!
    
    //Price section
    @IBOutlet weak var cheapVenueCell: UITableViewCell!
    @IBOutlet weak var moderateVenueCell: UITableViewCell!
    @IBOutlet weak var expensiveVenueCell: UITableViewCell!
    
    //Most popular section
    @IBOutlet weak var offeringDealCell: UITableViewCell!
    @IBOutlet weak var walkingDistanceCell: UITableViewCell!
    @IBOutlet weak var userTipsCell: UITableViewCell!
    
    //Sort section
    @IBOutlet weak var nameAZSortCell: UITableViewCell!
    @IBOutlet weak var nameZASortCell: UITableViewCell!
    @IBOutlet weak var distanceSortCell: UITableViewCell!
    @IBOutlet weak var priceSortCell: UITableViewCell!
    
    var coreDataStack: CoreDataStack!
    
    weak var delegate: FilterViewControllerDelegate?
    var selectedSortDescriptor: NSSortDescriptor?
    var selectedPredicate: NSPredicate?
    
    lazy var cheapVenuePredicate: NSPredicate = {
        return NSPredicate(format: "priceInfo.priceCategory == %@", "$")
    }()
    
    lazy var moderateVenuePredicate: NSPredicate = {
        return NSPredicate(format: "priceInfo.priceCategory == %@", "$$")
    }()
    
    lazy var expensiveVenuePredicate: NSPredicate = {
        return NSPredicate(format: "priceInfo.priceCategory == %@", "$$$")
    }()
    
    lazy var offeringDealPredicate: NSPredicate = {
        return NSPredicate(format: "specialCount > 0")
    }()
    
    lazy var walkingDistancePredicate: NSPredicate = {
        return NSPredicate(format: "location.distance < 1500")
    }()
    
    lazy var hasUserTipsPredicate: NSPredicate = {
        return NSPredicate(format: "stats.tipCount > 0")
    }()
    
    lazy var nameSortDescriptor: NSSortDescriptor = {
        return NSSortDescriptor(key: "name",
                                ascending: true,
                                selector: #selector(NSString.localizedStandardCompare(_:)))
    }()
    
    lazy var distanceSortDescriptor: NSSortDescriptor = {
        return NSSortDescriptor(key: "location.distance",
                                ascending: true)
    }()
    
    lazy var priceSortDescriptor: NSSortDescriptor = {
        return NSSortDescriptor(key: "priceInfo.priceCategory",
                                ascending: true)
    }()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        populateCheapVenueCountLabel()
        populateModerateVenueCountLabel()
        populateExpensiveVenueCountLabel()
        populateDealsCountLabel()
    }
    
    //MARK - UITableViewDelegate methods
    
    override func tableView(_ tableView: UITableView,
                            didSelectRowAt indexPath: IndexPath)
    {
        let cell = tableView.cellForRow(at: indexPath)!
        
        switch cell
        {
        // Price section
        case cheapVenueCell:
            selectedPredicate = cheapVenuePredicate
        case moderateVenueCell:
            selectedPredicate = moderateVenuePredicate
        case expensiveVenueCell:
            selectedPredicate = expensiveVenuePredicate
        //Most Popular section
        case offeringDealCell:
            selectedPredicate = offeringDealPredicate
        case walkingDistanceCell:
            selectedPredicate = walkingDistancePredicate
        case userTipsCell:
            selectedPredicate = hasUserTipsPredicate
        //Sort By section
        case nameAZSortCell:
            selectedSortDescriptor = nameSortDescriptor
        case nameZASortCell:
            selectedSortDescriptor =
                nameSortDescriptor.reversedSortDescriptor
                as? NSSortDescriptor
        case distanceSortCell:
            selectedSortDescriptor = distanceSortDescriptor
        case priceSortCell:
            selectedSortDescriptor = priceSortDescriptor
        default:
            print("default case")
        }
        
        cell.accessoryType = .checkmark
    }
    
    // MARK - UIButton target action
    
    @IBAction func saveButtonTapped(_ sender: UIBarButtonItem)
    {
        delegate?.filterViewController(self,
                                       didSelectPredicate: selectedPredicate,
                                       sortDescriptor: selectedSortDescriptor)
        
        dismiss(animated: true, completion:nil)
    }
    
    func populateCheapVenueCountLabel()
    {
        // $ fetch request
        let fetchRequest = NSFetchRequest<NSNumber>(entityName: "Venue")
        fetchRequest.resultType = .countResultType
        fetchRequest.predicate = cheapVenuePredicate
        
        do
        {
            let results = try coreDataStack.context.fetch(fetchRequest)
            
            let count = results.first?.intValue ?? 0
            
            firstPriceCategoryLabel.text = "\(count) bubble tea places"
        }
        catch let error as NSError
        {
            print("Could not fetch \(error), \(error.userInfo)")
        }
    }
    
    func populateModerateVenueCountLabel()
    {
        // $$ fetch request
        let fetchRequest = NSFetchRequest<NSNumber>(entityName: "Venue")
        fetchRequest.resultType = .countResultType
        fetchRequest.predicate = moderateVenuePredicate
        
        do
        {
            let results = try coreDataStack.context.fetch(fetchRequest)
            
            let count = results.first?.intValue ?? 0
            
            secondPriceCategoryLabel.text = "\(count) bubble tea places"
        }
        catch let error as NSError
        {
            print("Could not fetch \(error), \(error.userInfo)")
        }
    }
    
    func populateExpensiveVenueCountLabel()
    {
        // $$$ fetch request
        let fetchRequest = NSFetchRequest<Venue>(entityName: "Venue")
        fetchRequest.predicate = expensiveVenuePredicate
        
        do
        {
            let count = try coreDataStack.context.count(for: fetchRequest)
        
            if count != NSNotFound
            {
                thirdPriceCategoryLabel.text = "\(count) bubble tea places"
            }
        }
        catch
        {
            print("Could not fetch \(error)")
        }
    }
    
    func populateDealsCountLabel()
    {
        //1
        let fetchRequest = NSFetchRequest<NSDictionary>(entityName: "Venue")
        fetchRequest.resultType = .dictionaryResultType
        
        //2
        let sumExpressionDesc = NSExpressionDescription()
        sumExpressionDesc.name = "sumDeals"
        
        //3
        sumExpressionDesc.expression = NSExpression(forFunction: "sum:",
                                                    arguments:[NSExpression(forKeyPath: "specialCount")])
        
        sumExpressionDesc.expressionResultType = .integer32AttributeType
        
        //4
        fetchRequest.propertiesToFetch = [sumExpressionDesc]
        
        //5
        do
        {
            let results = try coreDataStack.context.fetch(fetchRequest)
            
            let resultDict =  results.first!
            let numDeals = resultDict["sumDeals"]
            numDealsLabel.text = "\(numDeals!) total deals"
        }
        catch let error as NSError
        {
            print("Could not fetch \(error), \(error.userInfo)")
        }
    }
}
