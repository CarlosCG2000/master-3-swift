//
//  NoteDetailViewController.swift
//  UnCloudNotes
//


import UIKit

class NoteDetailViewController: UIViewController
{
  var note : Note? {
    didSet {
      updateNoteInfo()
    }
  }
  
  @IBOutlet var titleField : UILabel!
  @IBOutlet var bodyField : UITextView!
  
  func updateNoteInfo() {
    if isViewLoaded, let note = note
    {
      titleField.text = String(note.title)
      bodyField.text = String(note.body)
    }
  }
  
  override func viewWillAppear(_ animated: Bool) {
    updateNoteInfo()
  }
  
}
