import Foundation
import UIKit
import CoreData

class Attachment : NSManagedObject {
        
}
