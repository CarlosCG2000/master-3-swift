@import UIKit

@interface NotesListViewController (Additions)

- (IBAction) unwindToNotesList:(UIStoryboardSegue *)segue;

@end
