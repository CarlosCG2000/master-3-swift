import UIKit
import CoreData

class NotesListViewController: UITableViewController, NSFetchedResultsControllerDelegate {
    let stack : CoreDataStack = CoreDataStack(
        modelName:"UnCloudNotesDataModel",
        storeName:"UnCloudNotes",
        options: [NSMigratePersistentStoresAutomaticallyOption :true, NSInferMappingModelAutomaticallyOption:false])
    
    let notes : NSFetchedResultsController<NSFetchRequestResult>
    
    required init?(coder aDecoder: NSCoder) {
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Note")
        request.sortDescriptors = [NSSortDescriptor(key: "dateCreated", ascending: false)]
        notes = NSFetchedResultsController(fetchRequest: request, managedObjectContext: stack.context, sectionNameKeyPath: nil, cacheName: nil)
        
        super.init(coder: aDecoder)
        
        notes.delegate = self
    }
    
    override func viewWillAppear(_ animated: Bool){
        super.viewWillAppear(animated)
        do {
            try notes.performFetch()
        } catch let error as NSError {
            print("Error fetching data \(error)")
        }
        tableView.reloadData()
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let objects = notes.fetchedObjects
        return objects?.count ?? 0
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let note = notes.fetchedObjects?[indexPath.row] as? Note
        let identifier = note?.image == nil ? "NoteCell" : "NoteCellImage"
        
        
        if let cell = tableView.dequeueReusableCell(withIdentifier: identifier, for: indexPath) as? NoteTableViewCell {
            
            cell.note = note
            return cell
        }
        return UITableViewCell()
    }
    
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?) {
        let indexPathsFromOptionals: (IndexPath?) -> [IndexPath] = { indexPath in
            if let indexPath = indexPath {
                return [indexPath]
            }
            return []
        }
        
        switch type
        {
        case .insert:
            tableView.insertRows(at: indexPathsFromOptionals(newIndexPath), with: .automatic)
        case .delete:
            tableView.deleteRows(at: indexPathsFromOptionals(indexPath), with: .automatic)
        default:
            break
        }
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>) {
    }
    
    @IBAction
    func unwindToNotesList(_ segue:UIStoryboardSegue) {
        NSLog("Unwinding to Notes List")
        
        if stack.context.hasChanges
        {
            do {
                try stack.context.save()
            } catch let error as NSError {
                print("Error saving context: \(error)")
            }
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "createNote"
        {
            let context = NSManagedObjectContext(concurrencyType: .mainQueueConcurrencyType)
            context.parent = stack.context
            if let navController = segue.destination as? UINavigationController {
                if let nextViewController = navController.topViewController as? CreateNoteViewController {
                    nextViewController.managedObjectContext = context
                }
            }
        }
        if segue.identifier == "showNoteDetail" {
            if let detailView = segue.destination as? NoteDetailViewController {
                if let selectedIndex = tableView.indexPathForSelectedRow {
                    if let objects = notes.fetchedObjects {
                        detailView.note = objects[selectedIndex.row] as? Note
                    }
                }
            }
        }
    }
}
