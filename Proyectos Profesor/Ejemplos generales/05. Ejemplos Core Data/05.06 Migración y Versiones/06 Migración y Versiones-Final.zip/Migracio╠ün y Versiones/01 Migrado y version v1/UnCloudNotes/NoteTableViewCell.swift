import UIKit


class NoteTableViewCell: UITableViewCell
{
    var note : Note? {
        didSet {
            updateNoteInfo()
        }
    }
    
    @IBOutlet var noteTitle : UILabel!
    @IBOutlet var noteCreateDate : UILabel!
    @IBOutlet var noteImage: UIImageView!
    
    func updateNoteInfo()
    {
        if let note = note
        {
            noteTitle.text = String(note.title)
            noteCreateDate.text = note.dateCreated.description
        }
    }
    
}
