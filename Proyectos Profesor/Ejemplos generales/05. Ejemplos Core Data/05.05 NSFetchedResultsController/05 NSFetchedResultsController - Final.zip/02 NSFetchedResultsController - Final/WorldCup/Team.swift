import Foundation
import CoreData

@objc(Team)
class Team: NSManagedObject {
    
    // Insert code here to add functionality to your managed object subclass
    
}
