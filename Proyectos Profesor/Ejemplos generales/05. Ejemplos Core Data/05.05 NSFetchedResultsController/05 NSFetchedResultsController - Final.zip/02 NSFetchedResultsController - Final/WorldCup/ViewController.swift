import UIKit
import CoreData

private let teamCellIdentifier = "teamCellReuseIdentifier"

class ViewController: UIViewController
{
    var coreDataStack: CoreDataStack!
    var fetchedResultsController : NSFetchedResultsController<Team>!
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var addButton: UIBarButtonItem!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()

        let fetchRequest = NSFetchRequest<Team>(entityName: "Team")
        
        let zoneSort = NSSortDescriptor (key: "qualifyingZone", ascending: true)
        
        let scoreSort = NSSortDescriptor (key: "wins", ascending: false)
        
        let nameSort = NSSortDescriptor (key: "teamName", ascending: true)
        
        fetchRequest.sortDescriptors = [zoneSort, scoreSort, nameSort]

        fetchedResultsController = NSFetchedResultsController(fetchRequest: fetchRequest,
                                                              managedObjectContext: coreDataStack.context,
                                                              sectionNameKeyPath: "qualifyingZone",
                                                              cacheName: "worldCup")
        
        fetchedResultsController.delegate = self
        
        do
        {
            try fetchedResultsController.performFetch()
        }
        catch let error as NSError
        {
            print("Could not fetch \(error), \(error.userInfo)")
        }
    }
    
    @IBAction func addTeam(_ sender: AnyObject)
    {
        let alert = UIAlertController(title: "Secret Team",
                                      message: "Add a new team",
                                      preferredStyle: UIAlertControllerStyle.alert)
        
        alert.addTextField { (textfield: UITextField!) -> Void in
            
            textfield.placeholder = "Team Name"
            
        }
        
        alert.addTextField { (
            textfield: UITextField!) -> Void in
            
            textfield.placeholder = "Qualifying Zone"
        }
        
        alert.addAction(UIAlertAction(title: "Save", style: .default, handler: { (action: UIAlertAction) -> Void in
            
            print("Saved")
            let nameTextField = alert.textFields!.first
            let zoneTextField = alert.textFields![1]
            
            let team = NSEntityDescription.insertNewObject(forEntityName: "Team", into: self.coreDataStack.context) as! Team
            
            team.teamName = nameTextField!.text
            team.qualifyingZone = zoneTextField.text
            team.imageName = "mimo-flag"
            
            self.coreDataStack.saveContext()
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: { (action: UIAlertAction) -> Void in
            print("Cancel")
        }))
        
        present(alert, animated: true, completion: nil)
    }
    
    func configureCell(_ cell: TeamCell, indexPath: IndexPath)
    {
        let team = fetchedResultsController.object(at: indexPath)
        
        cell.flagImageView.image = UIImage(named: team.imageName!)
        cell.teamLabel.text = team.teamName
        cell.scoreLabel.text = "Wins: \(team.wins!)"
    }
}

extension ViewController: UITableViewDataSource
{
    func numberOfSections
        (in tableView: UITableView) -> Int
    {
        // El número de secciones de nuestro tableView corresponde al número de secciones
        // de nuestro fetched results controller
        return fetchedResultsController.sections!.count
    }
    
    func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int
    {
        // El número de filas de cada sección corresponde al número de objetos
        // de cada sección del fetch results controller
        let sectionInfo = fetchedResultsController.sections![section]
        return sectionInfo.numberOfObjects
    }
    
    func tableView(_ tableView: UITableView,
                   cellForRowAt indexPath: IndexPath)
        -> UITableViewCell
    {
        let cell =
            tableView.dequeueReusableCell(
                withIdentifier: teamCellIdentifier, for: indexPath)
                as! TeamCell

        configureCell(cell, indexPath: indexPath)

        return cell
    }
}

extension ViewController: UITableViewDelegate
{
    func tableView(_ tableView: UITableView,
                   didSelectRowAt indexPath: IndexPath)
    {
        let team = fetchedResultsController.object(at: indexPath)
        
        let wins = team.wins!.intValue
        team.wins = NSNumber(value: wins+1 as Int)
        coreDataStack.saveContext()
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String?
    {
        let sectionInfo =  fetchedResultsController.sections![section]
        
        return sectionInfo.name
    }
}

extension ViewController:NSFetchedResultsControllerDelegate
{
    func controllerWillChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>)
    {
        tableView.beginUpdates()
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange anObject: Any, at indexPath: IndexPath?, for type: NSFetchedResultsChangeType, newIndexPath: IndexPath?)
    {
        switch type
        {
            case .insert:
                tableView.insertRows(at: [newIndexPath!], with: .automatic)
            case .delete:
                tableView.deleteRows(at: [indexPath!], with: .automatic)
            case .update:
                let cell = tableView.cellForRow(at: indexPath!) as! TeamCell
                configureCell(cell, indexPath: indexPath!)
            case .move:
                tableView.deleteRows(at: [indexPath!], with: .automatic)
                tableView.insertRows(at: [newIndexPath!], with: .automatic)
        }
    }
    
    func controllerDidChangeContent(_ controller: NSFetchedResultsController<NSFetchRequestResult>)
    {
        tableView.endUpdates()
    }
    
    func controller(_ controller: NSFetchedResultsController<NSFetchRequestResult>, didChange sectionInfo: NSFetchedResultsSectionInfo, atSectionIndex sectionIndex: Int, for type: NSFetchedResultsChangeType)
    {
        let indexSet = IndexSet(integer: sectionIndex)
        
        switch type
        {
            case .insert:
                tableView.insertSections(indexSet, with: .automatic)
            case .delete:
                tableView.deleteSections(indexSet, with: .automatic)
            default:
                break
        }
    }
}
