import UIKit
import CoreData

private let teamCellIdentifier = "teamCellReuseIdentifier"

class ViewController: UIViewController
{
    var coreDataStack: CoreDataStack!
    var fetchedResultsController : NSFetchedResultsController<Team>!
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var addButton: UIBarButtonItem!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        // TODO: setup fetched results controller, sorted by 1) zone, 2) wins and 3) team name
        // Then group (split in sections) by zone.
        
    }
    

    @IBAction func addTeam(_ sender: AnyObject)
    {
        
        let alert = UIAlertController(title: "Secret Team",
                                      message: "Add a new team",
                                      preferredStyle: UIAlertControllerStyle.alert)
        
        alert.addTextField { (textfield: UITextField!) -> Void in
            
            textfield.placeholder = "Team Name"
            
        }
        
        alert.addTextField { (
            textfield: UITextField!) -> Void in
            
            textfield.placeholder = "Qualifying Zone"
        }
        
        alert.addAction(UIAlertAction(title: "Save", style: .default, handler: { (action: UIAlertAction) -> Void in
            
            print("Saved")
            let nameTextField = alert.textFields!.first
            let zoneTextField = alert.textFields![1]
            
            let team = NSEntityDescription.insertNewObject(forEntityName: "Team", into: self.coreDataStack.context) as! Team
            
            team.teamName = nameTextField!.text
            team.qualifyingZone = zoneTextField.text
            team.imageName = "mimo-flag"
            
            self.coreDataStack.saveContext()
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .default, handler: { (action: UIAlertAction) -> Void in
            print("Cancel")
        }))
        
        present(alert, animated: true, completion: nil)
    }
    
    func configureCell(_ cell: TeamCell, indexPath: IndexPath)
    {
        let team = nil // TODO: get team for indexPath from the fetched results controller
        
        cell.flagImageView.image = UIImage(named: team.imageName!)
        cell.teamLabel.text = team.teamName
        cell.scoreLabel.text = "Wins: \(team.wins!)"
    }
}

extension ViewController: UITableViewDataSource
{

    // TODO: return sections info for table view from fetched results controller
    // HINT: section info = number of sections, number of rows per section, and title per section
    
    func tableView(_ tableView: UITableView,
                   cellForRowAt indexPath: IndexPath)
        -> UITableViewCell
    {
        let cell =
            tableView.dequeueReusableCell(
                withIdentifier: teamCellIdentifier, for: indexPath)
                as! TeamCell
        
        configureCell(cell, indexPath: indexPath)
        
        return cell
    }
}

extension ViewController: UITableViewDelegate
{
    func tableView(_ tableView: UITableView,
                   didSelectRowAt indexPath: IndexPath)
    {
        let team = nil // TODO: get team for indexPath from the fetched results controller
        
        let wins = team.wins!.intValue
        team.wins = NSNumber(value: wins+1 as Int)
        coreDataStack.saveContext()
    }
}

extension ViewController : NSFetchedResultsControllerDelegate
{
    
    // TODO: Implement NSFetchedResultsControllerDelegate methods to keep the table view up to date
    
}
