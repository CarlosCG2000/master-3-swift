import Foundation
import CoreData

extension Team {
    
    @NSManaged var imageName: String?
    @NSManaged var losses: NSNumber?
    @NSManaged var qualifyingZone: String?
    @NSManaged var teamName: String?
    @NSManaged var wins: NSNumber?
    
}
