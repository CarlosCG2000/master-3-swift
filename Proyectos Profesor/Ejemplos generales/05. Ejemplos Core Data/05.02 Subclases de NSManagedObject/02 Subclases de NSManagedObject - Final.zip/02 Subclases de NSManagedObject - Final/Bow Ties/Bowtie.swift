import Foundation
import CoreData

@objc(Bowtie)
class Bowtie: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
