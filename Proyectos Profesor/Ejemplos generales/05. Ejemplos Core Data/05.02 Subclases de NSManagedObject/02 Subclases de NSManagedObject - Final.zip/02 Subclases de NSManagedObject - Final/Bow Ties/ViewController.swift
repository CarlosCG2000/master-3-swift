import UIKit
import CoreData

class ViewController: UIViewController {

    @IBOutlet weak var segmentedControl: UISegmentedControl!
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var timesWornLabel: UILabel!
    @IBOutlet weak var lastWornLabel: UILabel!
    @IBOutlet weak var favoriteLabel: UILabel!

    var managedContext: NSManagedObjectContext!
    var currentBowtie: Bowtie!

    override func viewDidLoad() {
        super.viewDidLoad()

        //1
        insertSampleData()

        //2
        let request = NSFetchRequest<Bowtie>(entityName:"Bowtie")
        let firstTitle = segmentedControl.titleForSegment(at: 0) ?? ""

        request.predicate = NSPredicate(format:"searchKey == %@", firstTitle)

        do {
            let results = try managedContext.fetch(request)
            currentBowtie = results.first
            populate(currentBowtie)
        } catch let error as NSError {
            print("Could not fetch \(error), \(error.userInfo)")
        }
    }

    @IBAction func segmentedControl(_ control: UISegmentedControl) {

        let selectedValue = control.titleForSegment(at: control.selectedSegmentIndex) ?? ""

        let request = NSFetchRequest<Bowtie>(entityName:"Bowtie")

        request.predicate =
            NSPredicate(format:"searchKey == %@", selectedValue)

        do {
            let results = try managedContext.fetch(request)
            currentBowtie = results.first
            populate(currentBowtie)
        } catch let error as NSError {
            print("Could not fetch \(error), \(error.userInfo)")
        }
    }

    @IBAction func wear(_ sender: AnyObject) {
        let times = currentBowtie.timesWorn?.intValue ?? 0
        currentBowtie.timesWorn = NSNumber(value: (times + 1) as Int)

        currentBowtie.lastWorn = Date()

        do {
            try managedContext.save()
        } catch let error as NSError {
            print("Could not save \(error), \(error.userInfo)")
        }

        populate(currentBowtie)
    }

    @IBAction func rate(_ sender: AnyObject) {

        let alert = UIAlertController(title: "New Rating",
                                      message: "Rate this bow tie",
                                      preferredStyle: UIAlertControllerStyle.alert)

        let cancelAction = UIAlertAction(title: "Cancel",
                                         style: .default,
                                         handler: { (action: UIAlertAction!) in
        })

        let saveAction = UIAlertAction(title: "Save",
                                       style: .default,
                                       handler: { (action: UIAlertAction!) in

                                        let textField = alert.textFields!.first!
                                        self.updateRating(textField.text!)
        })

        alert.addTextField {
            (textField: UITextField!) in
            textField.keyboardType = .numberPad
        }

        alert.addAction(cancelAction)
        alert.addAction(saveAction)

        present(alert,
                animated: true,
                completion: nil)
    }

    func populate(_ bowtie: Bowtie) {
        imageView.image = UIImage(data:bowtie.photoData! as Data)
        nameLabel.text = bowtie.name
        ratingLabel.text = "Rating: \(bowtie.rating?.doubleValue ?? 0)/5"

        timesWornLabel.text = "# times worn: \(bowtie.timesWorn?.intValue ?? 0)"

        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .short
        dateFormatter.timeStyle = .none

        lastWornLabel.text = "Last worn: " + dateFormatter.string(from: bowtie.lastWorn!)

        favoriteLabel.isHidden = !bowtie.isFavorite!.boolValue

        view.tintColor = bowtie.tintColor as? UIColor
    }

    func updateRating(_ numericString: String) {

        currentBowtie.rating = (numericString as NSString).doubleValue as NSNumber?

        do {
            try managedContext.save()
            populate(currentBowtie)
        } catch let error as NSError {

            print("Could not save \(error), \(error.userInfo)")

            if error.domain == NSCocoaErrorDomain &&
                (error.code == NSValidationNumberTooLargeError ||
                    error.code == NSValidationNumberTooSmallError) {
                rate(currentBowtie)
            }
        }
    }

    //Insert sample data
    func insertSampleData() {
        let fetchRequest = NSFetchRequest<Bowtie>(entityName: "Bowtie")

        fetchRequest.predicate = NSPredicate(format: "searchKey != nil")

        let count = try! managedContext.count(for: fetchRequest)

        if count > 0 { return }

        let path = Bundle.main.path(forResource: "SampleData", ofType: "plist")
        let dataArray = NSArray(contentsOfFile: path!)!

        for dict : Any in dataArray {

            let entity = NSEntityDescription.entity(forEntityName: "Bowtie",
                                                    in: managedContext)

            let bowtie = Bowtie(entity: entity!, insertInto: managedContext)

            let btDict = dict as! NSDictionary

            bowtie.name = btDict["name"] as? String
            bowtie.searchKey = btDict["searchKey"] as? String
            bowtie.rating = btDict["rating"] as? NSNumber
            let tintColorDict = btDict["tintColor"] as? NSDictionary
            bowtie.tintColor = colorFromDict(tintColorDict!)

            let imageName = btDict["imageName"] as? String
            let image = UIImage(named:imageName!)
            let photoData = UIImagePNGRepresentation(image!)
            bowtie.photoData = photoData

            bowtie.lastWorn = btDict["lastWorn"] as? Date
            bowtie.timesWorn = btDict["timesWorn"] as? NSNumber
            bowtie.isFavorite = btDict["isFavorite"] as? NSNumber
        }
    }

    func colorFromDict(_ dict: NSDictionary) -> UIColor {
        let red = dict["red"] as! NSNumber
        let green = dict["green"] as! NSNumber
        let blue = dict["blue"] as! NSNumber

        let color = UIColor(red: CGFloat(red.floatValue)/255.0,
                            green: CGFloat(green.floatValue)/255.0,
                            blue: CGFloat(blue.floatValue)/255.0,
                            alpha: 1)

        return color
    }
}

