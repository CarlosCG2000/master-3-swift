import UIKit
import CoreData

class ViewController: UIViewController, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    var songs = [NSManagedObject]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "My Favourite songs"
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // TODO: Fetch all songs
    }

    //MARK : UITableViewDataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return songs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell")!
        
        // TODO: Configure cell with song
        
        return cell
    }
    
    
    @IBAction func addNameSong(_ sender: AnyObject) {
        
        
        let alert = UIAlertController(title: "New song",
            message: "Add a new song",
            preferredStyle: .alert)
        
        let saveAction = UIAlertAction(title: "Save",
            style: .default,
            handler: { (action:UIAlertAction) -> Void in
            
            let textField = alert.textFields!.first!
            self.saveName(textField.text!)
            self.tableView.reloadData()
        
        })
        
        let cancelAction = UIAlertAction (title: "Cancel",
            style: .default,
            handler: { (action:UIAlertAction) -> Void in
        })
        
        alert.addTextField { (textField: UITextField) -> Void in
            
        }
        
        alert.addAction(saveAction)
        alert.addAction(cancelAction)
        
        present(alert, animated: true, completion: nil)
    }
    
    func saveName(_ name: String) {
        
        // TODO: Create and save new song

    }
}

