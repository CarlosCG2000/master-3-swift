import UIKit
import CoreData

class ViewController: UIViewController, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    
    var songs = [NSManagedObject]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "My Favourite songs"
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        //1
        let appDelegate =
        UIApplication.shared.delegate as! AppDelegate
        
        let managedContext = appDelegate.managedObjectContext
        
        //2
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Song")
        
        //3
        do {
            songs = try managedContext.fetch(fetchRequest)
        } catch let error as NSError {
            print("Could not fetch \(error), \(error.userInfo)")
        }
    }

    //MARK : UITableViewDataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return songs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell")!
        
        let song = songs[indexPath.row]
        
        cell.textLabel!.text = song.value(forKey: "name") as? String
        
        return cell
    }
    
    
    @IBAction func addNameSong(_ sender: AnyObject) {
        
        
        let alert = UIAlertController(title: "New song",
            message: "Add a new song",
            preferredStyle: .alert)
        
        let saveAction = UIAlertAction(title: "Save",
            style: .default,
            handler: { (action:UIAlertAction) -> Void in
            
            let textField = alert.textFields!.first!
            self.saveName(textField.text!)
            self.tableView.reloadData()
        
        })
        
        let cancelAction = UIAlertAction (title: "Cancel",
            style: .default,
            handler: { (action:UIAlertAction) -> Void in
        })
        
        alert.addTextField { (textField: UITextField) -> Void in
            
        }
        
        alert.addAction(saveAction)
        alert.addAction(cancelAction)
        
        present(alert, animated: true, completion: nil)
    }
    
    func saveName(_ name: String) {
        //1
        let appDelegate =
        UIApplication.shared.delegate as! AppDelegate
        
        let managedContext = appDelegate.managedObjectContext
        
        //2
        let entity =  NSEntityDescription.entity(forEntityName: "Song",
            in:managedContext)!
        
        let song = NSManagedObject(entity: entity,
            insertInto: managedContext)
        
        //3
        song.setValue(name, forKey: "name")
        
        //4
        do {
            try managedContext.save()
            //5
            songs.append(song)
        } catch let error as NSError  {
            print("Could not save \(error), \(error.userInfo)")
        }
    }


}

