import UIKit
import CoreData

class AllWalksViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet var tableView: UITableView!
    
    lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .medium
        return formatter
    }()
    
    var walks: [Walk] = []
    
    var coreDataStack: CoreDataStack!
    var managedContext: NSManagedObjectContext! {
        get {
            return coreDataStack.context
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // TODO: Fetch all walks
    }
    
    func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        
        return walks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "DogWalkCell",
                                                 for: indexPath) as UITableViewCell
        
        // TODO: configure cell with walk date as title, and dog name as subtitle
        
        return cell
    }
}

