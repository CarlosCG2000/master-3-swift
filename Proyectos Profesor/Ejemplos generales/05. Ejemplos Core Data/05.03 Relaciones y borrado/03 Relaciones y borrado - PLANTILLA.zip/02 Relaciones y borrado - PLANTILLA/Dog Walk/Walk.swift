import Foundation
import CoreData


class Walk: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
