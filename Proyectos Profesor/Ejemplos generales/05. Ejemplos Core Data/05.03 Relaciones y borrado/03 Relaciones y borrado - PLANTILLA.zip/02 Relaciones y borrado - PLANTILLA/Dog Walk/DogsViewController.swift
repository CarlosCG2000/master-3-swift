import UIKit
import CoreData

class Algo {
    var perro: Dog?
}

class DogsViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet var tableView: UITableView!
    var dogs: [Dog] = []
    
    var coreDataStack: CoreDataStack!
    var managedContext: NSManagedObjectContext! {
        get {
            return coreDataStack.context
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // TODO: fetch all dogs
    }
    
    func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int {
        
        return dogs.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "DogCell",
                                                 for: indexPath) as UITableViewCell
        
        // TODO: configure cell with dog
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath) {
        guard editingStyle == .delete else {
            return
        }
        
        // TODO: delete dog from CoreData and list
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        switch segue.identifier! {
        case "Dog Walks":
            guard let walksVC = segue.destination as? WalksViewController,
                let cell = sender as? UITableViewCell,
                let indexPath = tableView.indexPath(for: cell)
                else {
                    return
            }
            
            let dog = dogs[indexPath.row]
            walksVC.coreDataStack = coreDataStack
            walksVC.dog = dog
        case "All Walks":
            guard let allWalksVC = segue.destination as? AllWalksViewController else {
                return
            }
            
            allWalksVC.coreDataStack = coreDataStack
        default:
            print("Unknown segue id: \(segue.identifier!)")
        }
        
    }
    
    @IBAction func add(_ sender: AnyObject) {
        
        let alert = UIAlertController(title: "New Dog",
                                      message: "Enter the name of the dog",
                                      preferredStyle: UIAlertControllerStyle.alert)
        
        let cancelAction = UIAlertAction(title: "Cancel",
                                         style: .default,
                                         handler: { (action: UIAlertAction!) in
        })
        
        let saveAction = UIAlertAction(title: "Add",
                                       style: .default,
                                       handler: { (action: UIAlertAction!) in
                                        
                                        let textField = alert.textFields![0] as UITextField
                                        self.addDog(textField.text!)
        })
        
        alert.addTextField {
            (textField: UITextField!) in
            textField.keyboardType = .numberPad
        }
        
        alert.addAction(cancelAction)
        alert.addAction(saveAction)
        
        present(alert,
                animated: true,
                completion: nil)
    }
    
    private func addDog(_ name: String) {
        
        // TODO: create dog and add it to list
    }
}

