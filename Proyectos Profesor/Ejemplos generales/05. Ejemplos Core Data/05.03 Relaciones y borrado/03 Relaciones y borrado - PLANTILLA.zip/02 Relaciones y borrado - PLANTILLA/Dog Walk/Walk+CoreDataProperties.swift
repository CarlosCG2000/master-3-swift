import Foundation
import CoreData

extension Walk {

    @NSManaged var date: Date?
    @NSManaged var dog: Dog?

}
