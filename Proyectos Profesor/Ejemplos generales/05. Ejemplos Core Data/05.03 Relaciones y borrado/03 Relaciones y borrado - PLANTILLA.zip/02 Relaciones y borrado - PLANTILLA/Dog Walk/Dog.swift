import Foundation
import CoreData


class Dog: NSManagedObject {

// Insert code here to add functionality to your managed object subclass

}
