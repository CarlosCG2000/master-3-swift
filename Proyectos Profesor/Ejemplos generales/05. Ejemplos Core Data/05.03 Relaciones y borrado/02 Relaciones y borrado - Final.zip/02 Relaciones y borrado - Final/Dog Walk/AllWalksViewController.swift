import UIKit
import CoreData

class AllWalksViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet var tableView: UITableView!
    
    lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .medium
        return formatter
    }()
    
    var walks: [Walk] = []
    
    var coreDataStack: CoreDataStack!
    var managedContext: NSManagedObjectContext! {
        get
        {
            return coreDataStack.context
        }
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let walkFetchRequest = NSFetchRequest<Walk>(entityName: "Walk")
        
        do
        {
            walks = try managedContext.fetch(walkFetchRequest)
        }
        catch
        {
            print("Error fetching walks: \(error)")
        }
    }
    
    func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int
    {
        return walks.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "DogWalkCell",
                                                 for: indexPath) as UITableViewCell
        
        let walk =  walks[indexPath.row]
        cell.textLabel!.text = dateFormatter.string(from: walk.date!)
        cell.detailTextLabel!.text = walk.dog!.name!
        
        return cell
    }
}

