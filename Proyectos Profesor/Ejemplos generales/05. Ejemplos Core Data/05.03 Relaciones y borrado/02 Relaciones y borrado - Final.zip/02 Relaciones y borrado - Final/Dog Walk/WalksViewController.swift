import UIKit
import CoreData

class WalksViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet var tableView: UITableView!
    
    lazy var dateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .short
        formatter.timeStyle = .medium
        return formatter
    }()
    
    var dog: Dog! {
        didSet
        {
            walks = (dog.walks?.array as? [Walk]) ?? []
            title = dog.name
            tableView?.reloadData()
        }
    }
    
    var walks: [Walk] = []
    
    var coreDataStack: CoreDataStack!
    var managedContext: NSManagedObjectContext! {
        get
        {
            return coreDataStack.context
        }
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    func tableView(_ tableView: UITableView,
                   numberOfRowsInSection section: Int) -> Int
    {
        return walks.count
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String?
    {
        return "List of Walks"
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "WalkCell",
                                                 for: indexPath) as UITableViewCell
        
        let walk =  walks[indexPath.row]
        cell.textLabel!.text = dateFormatter.string(from: walk.date!)
        
        return cell
    }
    
    @IBAction func add(_ sender: AnyObject)
    {
        let entity = NSEntityDescription.entity(forEntityName: "Walk",
                                                in: managedContext)!
        let walk = Walk(entity: entity, insertInto: managedContext)
        walk.date = Date()
        walk.dog = dog
        
        coreDataStack.saveContext()
        
        walks.append(walk)
        tableView.reloadData()
    }
}

