//
//  ViewController.swift
//  AutoLayoutAnimaciones
//
//  Created by Sergio Padrino Recio on 25/01/2020.
//  Copyright © 2020 Sergio. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var leadingConstraint: NSLayoutConstraint!
    @IBOutlet weak var trailingConstraint: NSLayoutConstraint!
    @IBOutlet weak var bottomConstraint: NSLayoutConstraint!
    @IBOutlet weak var topConstraint: NSLayoutConstraint!

    @IBOutlet weak var heightConstraint: NSLayoutConstraint!
    @IBOutlet weak var widthConstraint: NSLayoutConstraint!

    @IBOutlet weak var centerXConstraint: NSLayoutConstraint!
    @IBOutlet weak var centerYConstraint: NSLayoutConstraint!

    private var animation: Int = 0

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func animarButtonTapped(_ sender: Any)
    {
        animation += 1

        if animation == 6
        {
            animation = 0
        }

        print("Animacion \(animation)")

        // Guardamos en un array todas las constraints que posicionan la imagen
        let allConstraints: [NSLayoutConstraint] = [
            leadingConstraint,
            trailingConstraint,
            bottomConstraint,
            topConstraint,
            centerXConstraint,
            centerYConstraint,
        ]

        var constraintsToActivate: [NSLayoutConstraint] = []

        // Dependiendo de la animación, elegimos las constraints que queremos activar
        switch animation {
        case 0: // Centrado con tamaño original
            constraintsToActivate = [centerXConstraint, centerYConstraint]
            heightConstraint.constant = 105
            widthConstraint.constant = 270

        case 1: // Esquina superior izquierda
            constraintsToActivate = [leadingConstraint, topConstraint]
        case 2: // Esquina superior derecha
            constraintsToActivate = [trailingConstraint, topConstraint]
        case 3: // Esquina inferior derecha
            constraintsToActivate = [trailingConstraint, bottomConstraint]
        case 4: // Esquina inferior izquierda
            constraintsToActivate = [leadingConstraint, bottomConstraint]
        default: // Centrado pequeño
            constraintsToActivate = [centerXConstraint, centerYConstraint]
            heightConstraint.constant = 35
            widthConstraint.constant = 90
        }

        // Desactivamos todas las constraints para evitar conflictos
        NSLayoutConstraint.deactivate(allConstraints)

        // Activamos solo las constraints que queremos para la nueva posición de la imagen
        NSLayoutConstraint.activate(constraintsToActivate)

        // Animamos el proceso de layout...

        // ...con una animación lineal normal...
        UIView.animate(withDuration: 1) {
            self.view.layoutIfNeeded()
        }

        // ...o con efecto muelle/rebote
//        UIView.animate(withDuration: 1,
//                       delay: 0,
//                       usingSpringWithDamping: 0.25,
//                       initialSpringVelocity: 0.5,
//                       options: [],
//                       animations: {
//                        self.view.layoutIfNeeded()
//        },
//                       completion: nil)
    }
}

