//
//  ViewController.swift
//  AutoLayoutBasicoCodigo
//
//  Created by Sergio Padrino Recio on 25/01/2020.
//  Copyright © 2020 Sergio. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        let kSideMargin: CGFloat = 40.0

        let titleLabel = UILabel()
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.font = UIFont.boldSystemFont(ofSize: titleLabel.font.pointSize)
        titleLabel.text = "Título"
        view.addSubview(titleLabel)
        titleLabel.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: kSideMargin).isActive = true
        titleLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 0).isActive = true

        let titleDetailLabel = UILabel()
        titleDetailLabel.translatesAutoresizingMaskIntoConstraints = false
        titleDetailLabel.text = "Auto Layout Básico por Código"
        view.addSubview(titleDetailLabel)
        titleDetailLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor).isActive = true
        titleDetailLabel.topAnchor.constraint(equalToSystemSpacingBelow: titleLabel.bottomAnchor, multiplier: 1.0).isActive = true

        let descriptionLabel = UILabel()
        descriptionLabel.translatesAutoresizingMaskIntoConstraints = false
        descriptionLabel.font = UIFont.boldSystemFont(ofSize: descriptionLabel.font.pointSize)
        descriptionLabel.text = "Descripción"
        view.addSubview(descriptionLabel)
        descriptionLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor).isActive = true
        descriptionLabel.topAnchor.constraint(equalToSystemSpacingBelow: titleDetailLabel.bottomAnchor, multiplier: 1.0).isActive = true

        let descriptionDetailLabel = UILabel()
        descriptionDetailLabel.translatesAutoresizingMaskIntoConstraints = false
        descriptionDetailLabel.numberOfLines = 0;
        descriptionDetailLabel.text = """
        Lorem ipsum dolor sit amet, consectetur adipiscing elit. In vitae fermentum magna, nec laoreet elit. Nulla facilisi. Ut efficitur imperdiet eros vitae lobortis. Pellentesque ullamcorper dui metus, vitae venenatis augue interdum nec. Donec ut turpis et nisl bibendum auctor sit amet id nibh. Fusce volutpat ipsum orci, sit amet rhoncus ligula lobortis non. Phasellus lacinia nisl ut ligula fermentum volutpat. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Praesent semper tincidunt arcu, id convallis leo tempus vitae. Integer quis nibh eu lacus varius imperdiet nec quis urna. Proin facilisis fringilla ante laoreet scelerisque. Donec fermentum urna vitae nisi tempor, a vulputate mi dignissim. Ut tempor tortor a ligula egestas, auctor vulputate est commodo. Proin rutrum elit vel vehicula vehicula. Cras ut dolor ut elit accumsan efficitur.

        Nullam imperdiet ipsum sed lorem consectetur, sed convallis sapien imperdiet. Integer viverra ipsum enim, in bibendum tortor vestibulum eu. Curabitur vel ex elementum, placerat quam nec, tristique lectus. Fusce sem nulla, maximus et lacinia at, tempor ac nunc. Quisque luctus sapien laoreet mi fringilla, vestibulum sodales nulla bibendum. Donec bibendum urna non eros efficitur sollicitudin. Nunc ornare in dolor placerat accumsan. Cras imperdiet orci id odio blandit aliquam. Ut gravida massa ante, tincidunt efficitur mauris rutrum ac. Etiam tincidunt, diam ut gravida scelerisque, elit ligula sagittis diam, id laoreet leo lorem sit amet leo. Suspendisse efficitur diam a justo efficitur, quis pretium lacus vehicula.

        Mauris lacus velit, laoreet quis nisl eu, tempor ullamcorper lacus. Nam rhoncus rhoncus arcu, at consectetur sapien fermentum nec. Nullam dictum posuere arcu, nec tempor nunc auctor eu. Curabitur pharetra eros justo, in tristique enim condimentum nec. Ut quis dictum sem. Fusce non dui pellentesque, porttitor velit vel, tincidunt dolor. Nam a faucibus ex. In egestas, dolor ac gravida pharetra, nibh nisl imperdiet lectus, a ultricies est nisl eget magna. Etiam feugiat eros non nisi volutpat vulputate. Pellentesque condimentum in nulla a euismod. Duis sollicitudin odio aliquam eleifend semper. Pellentesque nunc libero, efficitur sed massa et, sagittis maximus risus. Suspendisse vitae ante enim.
        """
        view.addSubview(descriptionDetailLabel)
        descriptionDetailLabel.leadingAnchor.constraint(equalTo: titleLabel.leadingAnchor).isActive = true
        descriptionDetailLabel.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -kSideMargin).isActive = true
        descriptionDetailLabel.topAnchor.constraint(equalToSystemSpacingBelow: descriptionLabel.bottomAnchor, multiplier: 1.0).isActive = true
        descriptionDetailLabel.bottomAnchor.constraint(equalToSystemSpacingBelow: view.safeAreaLayoutGuide.bottomAnchor, multiplier: 1.0).isActive = true

        descriptionDetailLabel.setContentHuggingPriority(UILayoutPriority(rawValue: 1.0), for: .vertical)
        descriptionDetailLabel.setContentCompressionResistancePriority(UILayoutPriority(rawValue: 1.0), for: .vertical)
    }


}

