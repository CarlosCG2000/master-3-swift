//
//  CollapsableTextView.swift
//  AutoLayoutCustomViews
//
//  Created by Sergio Padrino Recio on 25/01/2020.
//  Copyright © 2020 Sergio. All rights reserved.
//

import UIKit

class CustomView: UIView {

    enum Style
    {
        case normal
        case big
        case small
    }

    var style: Style = .normal {
        didSet {
            self.invalidateIntrinsicContentSize()
        }
    }

    override var intrinsicContentSize: CGSize
    {
        switch style {
        case .normal:
            return CGSize(width: 200, height: 200)
        case .big:
            return CGSize(width: 300, height: 300)
        case .small:
            return CGSize(width: 100, height: 100)
        }
    }

}
