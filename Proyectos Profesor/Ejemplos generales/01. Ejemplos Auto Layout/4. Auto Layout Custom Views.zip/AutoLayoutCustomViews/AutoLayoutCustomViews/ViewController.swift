//
//  ViewController.swift
//  AutoLayoutCustomViews
//
//  Created by Sergio Padrino Recio on 25/01/2020.
//  Copyright © 2020 Sergio. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var customView: CustomView!

    override func viewDidLoad() {
        super.viewDidLoad()

    }

    @IBAction func cambiarEstilo(_ sender: Any)
    {
        var nextStyle: CustomView.Style = .normal

        switch customView.style {
        case .normal:
            nextStyle = .big
        case .big:
            nextStyle = .small
        case .small:
            nextStyle = .normal
        }

        customView.style = nextStyle

        UIView.animate(withDuration: 1) {
            self.view.layoutIfNeeded()
        }
    }


}

