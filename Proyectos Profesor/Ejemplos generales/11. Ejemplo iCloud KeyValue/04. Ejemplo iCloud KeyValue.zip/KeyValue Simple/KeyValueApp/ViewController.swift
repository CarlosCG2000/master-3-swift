import UIKit

class ViewController: UIViewController {

    var iCloudKeyStore: NSUbiquitousKeyValueStore = NSUbiquitousKeyValueStore()
    let iCloudTextKey = "iCloudText"
    
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var saveButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        iCloudSetUp()
    }

    override func didReceiveMemoryWarning() {
        
        super.didReceiveMemoryWarning()
    }
    
    
    @IBAction func saveText() {
        
        saveToiCloud()
    }
    
    //MARK : iCloud

    func iCloudSetUp() {
        NotificationCenter.default.addObserver(self,
                                               selector: #selector(ViewController.keyValueStoreDidChange(_:)),
                                               name: NSUbiquitousKeyValueStore.didChangeExternallyNotification,
                                               object: iCloudKeyStore)
        iCloudKeyStore.synchronize()
    }
    
    @objc func keyValueStoreDidChange(_ notification: Notification) {
 
        textField.text = iCloudKeyStore.string(forKey: iCloudTextKey)
        
    }
   
    func saveToiCloud() {
        iCloudKeyStore.set(textField.text, forKey: iCloudTextKey)
        iCloudKeyStore.synchronize()
    }
    

}

