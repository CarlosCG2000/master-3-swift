//
//  PhoneViewController.swift
//  EjemploAppUniversal
//
//  Created by Sergio Padrino Recio on 01/02/2020.
//  Copyright © 2020 Sergio. All rights reserved.
//

import UIKit

class PhoneViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func phoneButtonTapped(_ sender: Any)
    {
        let alertController = UIAlertController(title: "Aviso", message: "Pulsado botón específico del iPhone", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }


}
