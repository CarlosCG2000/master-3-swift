//
//  PadViewController.swift
//  EjemploAppUniversal
//
//  Created by Sergio Padrino Recio on 01/02/2020.
//  Copyright © 2020 Sergio. All rights reserved.
//

import UIKit

class PadViewController: BaseViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    

    @IBAction func padButtonTapped(_ sender: Any)
    {
        let alertController = UIAlertController(title: "Aviso", message: "Pulsado botón específico del iPad", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }

}
