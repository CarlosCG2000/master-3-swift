//
//  ViewController.swift
//  EjemploAppUniversal
//
//  Created by Sergio Padrino Recio on 01/02/2020.
//  Copyright © 2020 Sergio. All rights reserved.
//

import UIKit

class BaseViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func commonButtonTapped(_ sender: Any)
    {
        let deviceName = (UIDevice.current.userInterfaceIdiom == .pad
            ? "iPad"
            : "iPhone")

        let alertController = UIAlertController(title: "Aviso", message: "Pulsado botón común desde un \(deviceName)", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
}

