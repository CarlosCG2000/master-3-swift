//
//  ViewController.swift
//  EjemploCollectionView
//
//  Created by Sergio Padrino Recio on 26/01/2020.
//  Copyright © 2020 Sergio. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UICollectionViewDataSource, UICollectionViewDelegate {

    let sectionTitles = [
        "Números",
        "Letras",
        "Emojis",
    ]
    let sectionData = [
        [
            "1",
            "2",
            "3",
            "4",
            "5",
            "6",
        ],
        [
            "A",
            "B",
            "C",
            "D",
            "E",
            "F",
        ],
        [
            "😂",
            "😳",
            "🤪",
            "🧐",
            "🤯",
            "😇",
        ],
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    // MARK: UICollectionViewDataSource methods

    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return sectionTitles.count
    }

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return sectionData[section].count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "MyCustomCell", for: indexPath) as! CustomCollectionViewCell

        cell.titleLabel.text = sectionData[indexPath.section][indexPath.row]

        return cell
    }

    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let header = collectionView.dequeueReusableSupplementaryView(ofKind: kind, withReuseIdentifier: "MyCustomHeader", for: indexPath) as! CustomCollectionReusableView

        header.titleLabel.text = sectionTitles[indexPath.section]

        return header
    }

    // MARK: UICollectionViewDelegate methods

    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {

        // Al seleccionar una celda, cambiamos el layout con unos
        // valores dependientes del índice del elemento seleccionado
        //
        let size = 100.0 + CGFloat(indexPath.item) * 10.0
        let spacing = 20.0 + CGFloat(indexPath.item) * 5.0

        let layout = UICollectionViewFlowLayout()
        layout.itemSize = CGSize(width: size, height: size)
        layout.minimumLineSpacing = spacing
        layout.minimumInteritemSpacing = spacing
        layout.headerReferenceSize = CGSize(width: 50, height: 50) // Necesitamos dar un tamaño al header para que aparezca

        collectionView.setCollectionViewLayout(layout, animated: true)
    }

}

