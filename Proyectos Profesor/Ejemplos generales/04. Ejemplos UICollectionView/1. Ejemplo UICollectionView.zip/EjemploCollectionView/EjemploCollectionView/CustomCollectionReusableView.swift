//
//  CustomCollectionReusableView.swift
//  EjemploCollectionView
//
//  Created by Sergio Padrino Recio on 26/01/2020.
//  Copyright © 2020 Sergio. All rights reserved.
//

import UIKit

class CustomCollectionReusableView: UICollectionReusableView {
        
    @IBOutlet weak var titleLabel: UILabel!
}
