//
//  ViewController.swift
//  EjemploTableView
//
//  Created by Sergio Padrino Recio on 25/01/2020.
//  Copyright © 2020 Sergio. All rights reserved.
//

import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    let sectionTitles = [
        "Nintendo Switch",
        "Play Station 4",
        "Xbox One",
    ]
    let sectionData = [
        [
            ("Super Mario Odyssey", "Nintendo"),
            ("Zelda Breath of the Wild", "Nintendo"),
            ("Astral Chain", "PlatinumGames"),
        ],
        [
            ("Uncharted 4: A Thief's End", "Naughty Dog"),
            ("God of War 4", "SIE Santa Monica Studio"),
            ("Bloodborne", "From Software"),
        ],
        [
            ("Gears of War 5", "The Coalition"),
            ("Forza Motorsport 7", "Turn 10 Studios"),
            ("Halo 5: Guardians", "343 Industries"),
        ],
    ]

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    // MARK: UITableViewDataSource methods

    func numberOfSections(in tableView: UITableView) -> Int {
        return sectionTitles.count
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return sectionTitles[section]
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return sectionData[section].count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyCustomCell") as! CustomTableViewCell
        let (title, developer) = sectionData[indexPath.section][indexPath.row]
        cell.titleLabel.text = title
        cell.subtitleLabel.text = developer
        return cell
    }

    // MARK: UITableViewDelegate methods

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let (title, developer) = sectionData[indexPath.section][indexPath.row]

        let alertController = UIAlertController(title: "Aviso", message: "Has seleccionado \(title) de \(developer).", preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
        present(alertController, animated: true, completion: nil)
    }

}

