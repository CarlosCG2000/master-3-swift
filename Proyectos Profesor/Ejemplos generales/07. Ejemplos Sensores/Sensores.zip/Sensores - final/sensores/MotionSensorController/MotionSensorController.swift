import Foundation
import UIKit
import CoreMotion

class MotionSensorController: UIViewController
{
    @IBOutlet weak var xAcc: UILabel!
    @IBOutlet weak var yAcc: UILabel!
    @IBOutlet weak var zAcc: UILabel!
    
    @IBOutlet weak var xGyro: UILabel!
    @IBOutlet weak var yGyro: UILabel!
    @IBOutlet weak var zGyro: UILabel!
    
    var motionManager : CMMotionManager!
    
    override func viewDidLoad()
    {
        motionManager = CMMotionManager()
        motionManager.accelerometerUpdateInterval = 0.1
        motionManager.gyroUpdateInterval = 0.1
    }
    
    override func viewDidDisappear(_ animated: Bool)
    {
        motionManager.stopAccelerometerUpdates()
        motionManager.stopGyroUpdates()
    }
    
    @IBAction func updateButtonPressed(_ sender: AnyObject)
    {
        motionManager.startAccelerometerUpdates(to: OperationQueue.main) { [weak self] (data, error) in
            
            self?.xAcc.text = String(format: "X: %1f", data!.acceleration.x)
            self?.yAcc.text = "Y: \(data!.acceleration.y)"
            self?.zAcc.text = "Z: \(data!.acceleration.z)"
        }
        
        motionManager.startGyroUpdates(to: OperationQueue.main) { [weak self] (data, error) in
            
            self?.xGyro.text = "X: \(data!.rotationRate.x)"
            self?.yGyro.text = "Y: \(data!.rotationRate.y)"
            self?.zGyro.text = "Z: \(data!.rotationRate.z)"
        }
    }
}
