import UIKit
import CoreLocation

class LocationController: UIViewController, CLLocationManagerDelegate
{
    var locationManager : CLLocationManager!
    var locationStatus : NSString = "Not Started"
    
    @IBOutlet weak var locationStatusLabel: UILabel!
    @IBOutlet weak var latLabel: UILabel!
    @IBOutlet weak var longLabel: UILabel!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        locationStatusLabel.text = locationStatus as String
        
        locationManager = CLLocationManager()
        locationManager.delegate = self
        locationManager.requestAlwaysAuthorization()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.startUpdatingLocation()
        
        // Do any additional setup after loading the view.
    }
    
    override func viewDidDisappear(_ animated: Bool)
    {
        super.viewDidDisappear(animated)
        locationManager.stopUpdatingLocation()
    }

    // Location Manager Delegate stuff
    // If failed
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error)
    {
        locationManager.stopUpdatingLocation()
    }
    
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        let locationArray = locations as NSArray
        let locationObj = locationArray.lastObject as! CLLocation
        let coord = locationObj.coordinate
        
        latLabel.text = "Latitude: \(coord.latitude)"
        longLabel.text = "Longitude: \(coord.longitude)"
    }
    
    // authorization status
    func locationManager(_ manager: CLLocationManager,
                         didChangeAuthorization status: CLAuthorizationStatus)
    {
        var shouldIAllow = false
        
        switch status
        {
            case CLAuthorizationStatus.restricted:
                locationStatus = "Restricted Access to location"
            case CLAuthorizationStatus.denied:
                locationStatus = "User denied access to location"
            case CLAuthorizationStatus.notDetermined:
                locationStatus = "Status not determined"
            default:
                locationStatus = "Allowed to location Access"
                shouldIAllow = true
        }

        permissionsLocation(locationStatus as String)

        if (shouldIAllow == true)
        {
            NSLog("Location to Allowed")
            // Start location services
            locationManager.startUpdatingLocation()
        }
        else
        {
            NSLog("Denied access: \(locationStatus)")
        }
    }
    
    func permissionsLocation (_ status: String)
    {
        locationStatusLabel.text = locationStatus as String
    }
}
