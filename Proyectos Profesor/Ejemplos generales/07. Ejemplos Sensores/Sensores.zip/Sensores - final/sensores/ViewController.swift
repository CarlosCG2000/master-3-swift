import UIKit

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    @IBOutlet weak var tableView: UITableView!
    let tableCellTexts = [
        "Device Orientation",
        "Shake Device",
        "Proximity",
        "Motion sensors",
        "Magnetometer",
        "GPS"
    ]

    override func viewDidLoad()
    {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        title = "iOS Sensors"
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
    }
    
    //MARK: UITableViewDataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return tableCellTexts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell")
        
        cell!.textLabel!.text = tableCellTexts[indexPath.row]
        
        return cell!
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)

        switch (indexPath.row)
        {
            case 0:
                self.navigationController?.pushViewController(storyboard.instantiateViewController(withIdentifier: "deviceOrientationVC"), animated: true)

            case 1:
                self.navigationController?.pushViewController(storyboard.instantiateViewController(withIdentifier: "shakeVC"), animated: true)

            case 2:
                self.navigationController?.pushViewController(storyboard.instantiateViewController(withIdentifier: "proximityVC"), animated: true)

            case 3:
                self.navigationController?.pushViewController(storyboard.instantiateViewController(withIdentifier: "motionVC"), animated: true)

            case 4:
                self.navigationController?.pushViewController(storyboard.instantiateViewController(withIdentifier: "magnetometerVC"), animated: true)

            case 5:
                self.navigationController?.pushViewController(storyboard.instantiateViewController(withIdentifier: "locationVC"), animated: true)

            default:
                // Do nothing
                break
        }
    }
}

