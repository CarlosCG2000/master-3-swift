import Foundation
import UIKit

class ProximityController: UIViewController
{
    @IBOutlet weak var label: UILabel!
    
    override func viewDidLoad()
    {
        UIDevice.current.isProximityMonitoringEnabled = true
        NotificationCenter.default.addObserver(self, selector: #selector(ProximityController.proximityStateDidChangeNotification), name: NSNotification.Name.UIDeviceProximityStateDidChange, object: nil)
        label.text = "Device is NOT close to user"
    }
    
    deinit
    {
        UIDevice.current.isProximityMonitoringEnabled = false
    }
    
    
    @objc func proximityStateDidChangeNotification()
    {
        if (UIDevice.current.proximityState == true)
        {
            label.text = "Device is close to user"
        }
        else
        {
            label.text = "Device is NOT close to user"
        }
    }
}
