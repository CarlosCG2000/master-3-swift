import Foundation
import UIKit
import CoreMotion

class MagnetometerController: UIViewController
{
    @IBOutlet weak var yMagne: UILabel!
    @IBOutlet weak var xMagne: UILabel!
    @IBOutlet weak var zMagne: UILabel!

    var motionManager : CMMotionManager!

    override func viewDidLoad()
    {
        motionManager = CMMotionManager()
        motionManager.magnetometerUpdateInterval = 0.5
    }
    
    override func viewDidDisappear(_ animated: Bool)
    {
        motionManager.stopMagnetometerUpdates()
    }
    
    @IBAction func updateMagnetometerValues(_ sender: AnyObject)
    {
        motionManager.startMagnetometerUpdates (to: OperationQueue.main) { [weak self] (data, error) in
            
            self?.xMagne.text = "X: \(data!.magneticField.x)"
            self?.yMagne.text = "Y: \(data!.magneticField.y)"
            self?.zMagne.text = "Z: \(data!.magneticField.z)"
        }
    }
    
}
