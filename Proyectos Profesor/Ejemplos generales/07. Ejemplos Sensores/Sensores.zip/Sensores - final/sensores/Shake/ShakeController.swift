import Foundation
import UIKit

class ShakeController: UIViewController
{
    @IBOutlet weak var labelShake: UILabel!
    
    override func viewDidLoad()
    {
        title = "Shake device"
        labelShake.text = "Try shake"
    }
    
    override func motionBegan(_ motion: UIEventSubtype, with event: UIEvent?)
    {
        labelShake.text = "Shaking it"
    }
    
    override func motionEnded(_ motion: UIEventSubtype, with event: UIEvent?)
    {
        if (motion == UIEventSubtype.motionShake)
        {
            self.view.backgroundColor = getRandomColor()
        }
        
        labelShake.text = "Try Again"
    }
    
    func getRandomColor() -> UIColor
    {
        let randomRed:CGFloat = CGFloat(drand48())
        let randomGreen:CGFloat = CGFloat(drand48())
        let randomBlue:CGFloat = CGFloat(drand48())
        
        return UIColor(red: randomRed, green: randomGreen, blue: randomBlue, alpha: 1.0)
    }
}
