import Foundation
import UIKit

class DeviceOrientationController : UIViewController
{
    @IBOutlet weak var labelOrientation: UILabel!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        UIDevice.current.beginGeneratingDeviceOrientationNotifications()
        NotificationCenter.default.addObserver(self, selector: #selector(DeviceOrientationController.deviceDidChangeOrientation), name: NSNotification.Name.UIDeviceOrientationDidChange, object: nil)
        view.backgroundColor = UIColor.blue
        title = "Device Orientation"
    }
    
    deinit
    {
        UIDevice.current.endGeneratingDeviceOrientationNotifications()
    }
    
    @objc func deviceDidChangeOrientation()
    {
        switch (UIDevice.current.orientation)
        {
            case .portrait:
                self.view.backgroundColor = UIColor.red
                labelOrientation.text = "Portrait"

            case .landscapeLeft:
                self.view.backgroundColor = UIColor.green
                labelOrientation.text = "LandscapeLeft"

            case .landscapeRight:
                self.view.backgroundColor = UIColor.orange
                labelOrientation.text = "LandscapeRight"

            case .portraitUpsideDown:
                self.view.backgroundColor = UIColor.black
                labelOrientation.text = "PortraitUpsideDown"

            case .faceUp:
                self.view.backgroundColor = UIColor.purple
                labelOrientation.text = "FaceUp"

            case .faceDown:
                self.view.backgroundColor = UIColor.yellow
                labelOrientation.text = "FaceDown"

            case .unknown:
                self.view.backgroundColor = UIColor.white
                labelOrientation.text = "Unknown"
        }
    }
    
}
