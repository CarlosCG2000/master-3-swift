import UIKit
import CoreMotion

class LiveViewController: UIViewController
{
    @IBOutlet weak var activityImageView: UIImageView!
    @IBOutlet weak var stepsLabel: UILabel!
    @IBOutlet weak var floorsLabel: UILabel!
    @IBOutlet weak var distanceLabel: UILabel!
    @IBOutlet weak var altitudeLabel: UILabel!
    
    let dataProcessingQueue = OperationQueue()
    let pedometer = CMPedometer()
    let altimeter = CMAltimeter()
    let activityManager = CMMotionActivityManager()
    
    let lengthFormatter = LengthFormatter()
    
    var altChange: Double = 0
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        lengthFormatter.numberFormatter.usesSignificantDigits = false
        lengthFormatter.numberFormatter.maximumSignificantDigits = 2
        lengthFormatter.unitStyle = .short
        
        // Altimeter
        altimeter.startRelativeAltitudeUpdates(to: dataProcessingQueue) {
            (data, error) in

            if error != nil
            {
                print("There was an error obtaining altimeter data: \(String(describing: error))")
            }
            else
            {
                DispatchQueue.main.async {
                    self.altChange = data!.relativeAltitude.doubleValue
                    self.altitudeLabel.text = "\(self.lengthFormatter.string(fromMeters: self.altChange))"
                }
            }
        }
        
        // Pedometer
        pedometer.startUpdates(from: Date()) {
            (data, error) in
            
            if error != nil
            {
                print("There was an error obtaining pedometer data: \(String(describing: error))")
            }
            else
            {
                DispatchQueue.main.async {
                    self.stepsLabel.text = "\(data!.numberOfSteps)"
                    self.distanceLabel.text = "\(round(data!.distance?.doubleValue ?? 0))"
                    self.floorsLabel.text = "\(round(data!.floorsAscended?.doubleValue ?? 0))"
                }
            }
        }
        
        // Activity updates
        activityManager.startActivityUpdates(to: OperationQueue.main) {
            data in
            
            if data!.running
            {
                self.activityImageView.image = UIImage(named: "run")
            }
            else if data!.cycling
            {
                self.activityImageView.image = UIImage(named: "cycle")
            }
            else if data!.walking
            {
                self.activityImageView.image = UIImage(named: "walk")
            }
            else
            {
                self.activityImageView.image = nil
            }
        }
    }
    
}

