import UIKit
import CoreMotion

class LiveViewController: UIViewController
{
    @IBOutlet weak var activityImageView: UIImageView!
    @IBOutlet weak var stepsLabel: UILabel!
    @IBOutlet weak var floorsLabel: UILabel!
    @IBOutlet weak var distanceLabel: UILabel!
    @IBOutlet weak var altitudeLabel: UILabel!
    
    let dataProcessingQueue = OperationQueue()
    let pedometer = CMPedometer()
    let altimeter = CMAltimeter()
    let activityManager = CMMotionActivityManager()
    
    let lengthFormatter = LengthFormatter()
    
    var altChange: Double = 0
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        lengthFormatter.numberFormatter.usesSignificantDigits = false
        lengthFormatter.numberFormatter.maximumSignificantDigits = 2
        lengthFormatter.unitStyle = .short
        
        // TODO: observe altimeter and update the altitudeLabel.
        // HINT: use the lengthFormatter to format the text properly from meters

        // TODO: observe pedometer and update steps, distance and floors with it

        // TODO: observe activity changes and update the activity imageView (images: "run", "cycle" and "walk")
    }
}

