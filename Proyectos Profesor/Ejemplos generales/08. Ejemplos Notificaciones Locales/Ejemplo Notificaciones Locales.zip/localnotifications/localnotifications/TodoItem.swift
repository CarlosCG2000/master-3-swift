import Foundation
import CoreData


class TodoItem: NSManagedObject
{
    // Insert code here to add functionality to your managed object subclass
}
