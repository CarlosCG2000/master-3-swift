import Foundation
import CoreData

extension TodoItem
{
    @NSManaged var title: String?
    @NSManaged var deadline: Date?
}
