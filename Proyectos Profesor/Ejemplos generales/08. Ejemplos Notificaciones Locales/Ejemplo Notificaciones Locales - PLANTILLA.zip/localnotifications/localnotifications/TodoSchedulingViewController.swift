import UIKit
import CoreData
import UserNotifications

class TodoSchedulingViewController: UIViewController
{
    @IBOutlet weak var titleField: UITextField!
    @IBOutlet weak var dataPicker: UIDatePicker!
    lazy var coreDataStack = CoreDataStack()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let saveButton = UIBarButtonItem(barButtonSystemItem: .save, target: self, action: #selector(saveTodo(_:)))
        navigationItem.rightBarButtonItem = saveButton
    }
    
    @IBAction func saveTodo(_ sender: UIButton)
    {
        let itemEntity = NSEntityDescription.entity(forEntityName: "TodoItem", in: coreDataStack.context)
        let item = TodoItem(entity: itemEntity!, insertInto: coreDataStack.context)
        item.title =  titleField.text
        item.deadline = dataPicker.date.addingTimeInterval(10)
        coreDataStack.saveContext()
        createLocalNotification(item)
        _ = self.navigationController?.popToRootViewController(animated: true)
    }
    
    func createLocalNotification(_ item: TodoItem)
    {
        // TODO: configure and schedule a notification request for the TODO item.
        // HINTS:
        // Body: "Todo Item <title> Is Overdue"
        // Identifier: You can use the <title>, but use always a different title!
    }
}
