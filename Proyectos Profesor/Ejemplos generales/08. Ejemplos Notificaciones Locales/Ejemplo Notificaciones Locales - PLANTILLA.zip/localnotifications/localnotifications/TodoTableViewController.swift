import UIKit
import CoreData

class TodoTableViewController: UITableViewController
{
    var todoItems : [TodoItem]!
    var coreDataStack : CoreDataStack!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        NotificationCenter.default.addObserver(self, selector: #selector(TodoTableViewController.refreshList), name: NSNotification.Name(rawValue: "TodoListShouldRefresh"), object: nil)
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }
    
    override func viewWillAppear(_ animated: Bool)
    {
        super.viewWillAppear(animated)
        
        let request = NSFetchRequest<NSFetchRequestResult>(entityName: "TodoItem")
        
        do
        {
            let results = try coreDataStack.context.fetch(request) as! [TodoItem]
            todoItems = results
            tableView.reloadData()
        }
        catch let error as NSError
        {
            print("Could not fetch \(error): \(error.userInfo)")
        }
    }
    
    
    @objc func refreshList()
    {
        if (todoItems.count >= 64)
        {
            self.navigationItem.rightBarButtonItem!.isEnabled = false // disable 'add' button
        }
        tableView.reloadData()
    }
    
    // MARK: - Table view data source
    
    override func numberOfSections(in tableView: UITableView) -> Int
    {
        return 1;
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return todoItems.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "todoCell", for: indexPath)
        let items = todoItems[indexPath.row]
        
        cell.textLabel?.text = items.title ?? ""
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "'Notify me:' dd MMMM  'at' h:mm a"
        cell.detailTextLabel?.text = dateFormatter.string(from: items.deadline! as Date)
        
        return cell
    }
    
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool
    {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        if editingStyle == .delete // the only editing style we'll support
        {
            // delete the row from the data source
            let item = todoItems.remove(at: indexPath.row) as TodoItem // remove TodoItem from notifications array, assign removed item to 'item'
            
            coreDataStack.context.delete(item)
            
            do
            {
                try coreDataStack.context.save()
            }
            catch let error as NSError
            {
                print("Could not save: \(error)")
            }
            
            tableView.deleteRows(at: [indexPath], with: .fade)
            self.navigationItem.rightBarButtonItem!.isEnabled = true // we definitely have under 64 notifications scheduled now, make sure 'add' button is enabled
        }
    }
}
