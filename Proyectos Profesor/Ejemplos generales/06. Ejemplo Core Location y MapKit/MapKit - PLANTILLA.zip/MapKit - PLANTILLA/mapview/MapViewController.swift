import UIKit
import MapKit
import CoreLocation

class MapViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate
{
    @IBOutlet weak var mapView: MKMapView!
    var locationManager : CLLocationManager!

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        title = "Salamanca's interest points"
        
        locationManager = CLLocationManager()
        locationManager.requestWhenInUseAuthorization()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        
        mapView.delegate = self
        let annotations = getMapAnnotations()
        mapView.addAnnotations(annotations)
    }

    //MARK - Location Manager
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus)
    {
        if (ProcessInfo.processInfo.environment["SIMULATOR_DEVICE_NAME"] != nil)
        {
            print("Usando simulador")
        }
        else
        {
            switch status
            {
                case .authorizedWhenInUse:

                    let center = CLLocationCoordinate2D(latitude: manager.location!.coordinate.latitude, longitude: manager.location!.coordinate.longitude)
                    let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))

                    mapView.setRegion(region, animated: true)

                    manager.startUpdatingLocation()

                    break

                default:
                    print("Other location permission: \(status)")
                    break
            }
        }
    }
    
    //MARK : Actions Buttons
    
    @IBAction func StandardAction(_ sender: AnyObject)
    {
        // TODO: switch map type to standard
    }
    
    @IBAction func SatelliteAction(_ sender: AnyObject)
    {
        // TODO: switch map type to satellite
    }
    
    @IBAction func HybridAction(_ sender: AnyObject)
    {
        // TODO: switch map type to hybrid
    }

    //MARK : Annotations
    
    func getMapAnnotations() -> [SalamancaPlacesPin]
    {
        var annotations:Array = [SalamancaPlacesPin]()
        
        //load plist
        
        var salamancaplaces: NSArray?
        
        if let path = Bundle.main.path(forResource: "salamanca_places", ofType: "plist")
        {
            salamancaplaces = NSArray(contentsOfFile: path)
        }
        
        if let items = salamancaplaces
        {
            for dict in items
            {
                let lat = (dict as AnyObject).value(forKey: "latitude") as! Double
                let long = (dict as AnyObject).value(forKey: "longitude") as! Double
                let titleDict = (dict as AnyObject).value(forKey: "title") as? String
                let subtitleDict = (dict as AnyObject).value(forKey: "subtitle") as? String
                let idDict = (dict as AnyObject).value(forKey: "id") as! Int
                let imageDict = (dict as AnyObject).value(forKey: "imageName") as? String
                
                // TODO: configure map annotation and append to final list (HINT: check the SalamancaPlacesPin class)
            }
        }
        
        return annotations
    }
    
    //MARK AnnotationView 
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView?
    {
        // TODO: dequeue and configure a reusable Pin annotation view with the content of the annotation.
        // HINT: you'll need to enable the callout

        return nil
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl)
    {
        let salamancaPin = view.annotation as! SalamancaPlacesPin
        
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        let vc = storyboard.instantiateViewController(withIdentifier: "detailVC") as! detailPlaceViewController

        vc.detailPin = salamancaPin

        self.navigationController?.pushViewController(vc, animated: true)
    }
}
