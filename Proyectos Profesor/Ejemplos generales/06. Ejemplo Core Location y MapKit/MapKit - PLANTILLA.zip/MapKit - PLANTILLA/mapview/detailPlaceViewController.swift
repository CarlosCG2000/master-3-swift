import UIKit
import Foundation
import CoreLocation

class detailPlaceViewController: UIViewController, UITableViewDataSource, UITableViewDelegate
{
    @IBOutlet weak var imagePlace: UIImageView!
    @IBOutlet weak var tableView: UITableView!
    var detailCoord : CLLocationCoordinate2D!
    var detailName : String!
    var detailSubtitle: String!
    var detailPin : SalamancaPlacesPin!
    
    var geoCoder : CLGeocoder!
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.isOpaque = true
        
        self.tableView.delegate = self
        self.tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        self.tableView.rowHeight = UITableViewAutomaticDimension
        self.tableView.estimatedRowHeight = 160.0
        self.automaticallyAdjustsScrollViewInsets = false
        imagePlace.image = UIImage(named: detailPin.imageName!)
        title = detailPin.title
        
        geoCoder = CLGeocoder()
    }
    
    //MARK : TableView DataSource
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return 4
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell")
        cell?.textLabel?.numberOfLines = 0
        
        switch indexPath.row
        {
            case 0:
                cell?.textLabel?.text = detailPin.title
                break

            case 1:
                cell?.textLabel?.text = detailPin.subtitle
                break

            case 2:

                // TODO: reverse-geocode coordinates into a "human readable" address

                break
            case 3:
                cell?.textLabel?.text = "Route from Apple Maps"
                break

            default:
                print ("other cell")
        }

        return cell!
    }
    
    //MARK : TableView Delegate
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return UITableViewAutomaticDimension
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath)
    {
        if (indexPath.row == 3)
        {
            // TODO: open location in Apple Maps
        }
    }
}
