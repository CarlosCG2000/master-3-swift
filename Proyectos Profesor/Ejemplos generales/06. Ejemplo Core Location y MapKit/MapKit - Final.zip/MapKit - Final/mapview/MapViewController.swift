import UIKit
import MapKit
import CoreLocation

class MapViewController: UIViewController, MKMapViewDelegate, CLLocationManagerDelegate
{
    @IBOutlet weak var mapView: MKMapView!
    var locationManager : CLLocationManager!

    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        title = "Salamanca's interest points"
        
        locationManager = CLLocationManager()
        locationManager.requestWhenInUseAuthorization()
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.delegate = self
        
        mapView.delegate = self
        let annotations = getMapAnnotations()
        mapView.addAnnotations(annotations)
    }

    //MARK - Location Manager
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus)
    {
        if (ProcessInfo.processInfo.environment["SIMULATOR_DEVICE_NAME"] != nil)
        {
            print("Usando simulador")
        }
        else
        {
            switch status
            {
                case .authorizedWhenInUse:

                    let center = CLLocationCoordinate2D(latitude: manager.location!.coordinate.latitude, longitude: manager.location!.coordinate.longitude)
                    let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))

                    mapView.setRegion(region, animated: true)

                    manager.startUpdatingLocation()
                    break

                default:
                    print("Other location permission: \(status)")
                    break
            }
        }
    }
    
    //MARK : Actions Buttons
    
    @IBAction func StandardAction(_ sender: AnyObject)
    {
        self.mapView.mapType = .standard
    }
    
    @IBAction func SatelliteAction(_ sender: AnyObject)
    {
        self.mapView.mapType = .satellite
    }
    
    @IBAction func HybridAction(_ sender: AnyObject)
    {
        self.mapView.mapType = .hybrid
    }

    //MARK : Annotations
    
    func getMapAnnotations() -> [SalamancaPlacesPin]
    {
        var annotations:Array = [SalamancaPlacesPin]()
        
        // load plist
        
        var salamancaPlaces: NSArray?
        
        if let path = Bundle.main.path(forResource: "salamanca_places", ofType: "plist")
        {
            salamancaPlaces = NSArray(contentsOfFile: path)
        }
        
        if let items = salamancaPlaces
        {
            for dict in items
            {
                let lat = (dict as AnyObject).value(forKey: "latitude") as! Double
                let long = (dict as AnyObject).value(forKey: "longitude") as! Double
                let titleDict = (dict as AnyObject).value(forKey: "title") as? String
                let subtitleDict = (dict as AnyObject).value(forKey: "subtitle") as? String
                let idDict = (dict as AnyObject).value(forKey: "id") as! Int
                let imageDict = (dict as AnyObject).value(forKey: "imageName") as? String
                
                let annotation =  SalamancaPlacesPin(lat: lat, long: long, ident: idDict, image: imageDict!)
                
                annotation.title = titleDict
                annotation.subtitle = subtitleDict
                annotation.imageName = imageDict
                annotations.append(annotation)
            }
        }
        
        return annotations
    }
    
    //MARK AnnotationView 
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView?
    {
        // 1
        let identifier = "Capital"
        
        // 2
        if annotation.isKind(of: SalamancaPlacesPin.self)
        {
            // 3
            var annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: identifier)
            
            if annotationView == nil
            {
                //4
                annotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
                
            }
            else
            {
                // 5
                annotationView!.annotation = annotation
            }
            
            annotationView!.canShowCallout = true
            
            // 6
            let btn = UIButton(type: .detailDisclosure)
            annotationView!.rightCalloutAccessoryView = btn

            let annotationPins = annotation as! SalamancaPlacesPin
            
            print ("anotation : \(annotationPins.imageName!)")
            
            let imageView = UIImageView(image: UIImage(named:annotationPins.imageName!))
            imageView.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
            annotationView!.leftCalloutAccessoryView = imageView
            
            return annotationView!
        }
        
        // 7
        return nil
    }
    
    func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl)
    {
        let salamancaPin = view.annotation as! SalamancaPlacesPin
        
        let storyboard = UIStoryboard(name: "Main", bundle: Bundle.main)
        let vc = storyboard.instantiateViewController(withIdentifier: "detailVC") as! detailPlaceViewController

        vc.detailPin = salamancaPin

        self.navigationController?.pushViewController(vc, animated: true)
    }
}
