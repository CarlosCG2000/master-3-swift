import UIKit
import MapKit
import Foundation

class SalamancaPlacesPin: NSObject, MKAnnotation
{
    var title : String?
    var subtitle : String?
    var latitude : Double
    var longitude : Double
    var identifier : Int
    var imageName : String?
    
    var coordinate : CLLocationCoordinate2D
    {
        return CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
    }
    
    init(lat: Double, long: Double, ident: Int, image: String)
    {
        self.latitude = lat
        self.longitude = long
        self.identifier = ident
        self.imageName = image
    }

}
